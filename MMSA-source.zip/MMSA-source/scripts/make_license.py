#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""توليد ملف ترخيص مشفر (AES-256-GCM) + ثوابت موهّة بـ XOR لملف License.java.
لا يظهر نص الترخيص ولا المفتاح السري نصاً واضحاً في الكود أو داخل APK."""
import os
import secrets
from Crypto.Cipher import AES

OUT = "/home/z/my-project/work/MMSA/app/src/main/assets/license.dat"
SRC_KEY = "Alsidi_Group108797"      # مفتاح المصدر — يُخزن موهّاً فقط
SECRET_PIN = "10101994"             # الرقم السري — يُخزن موهّاً فقط

LICENSE_TEXT = """ترخيص استخدام خاص — منظومة البيانات
الإصدار 1.1.0 — تاريخ التحرير: 19 نوفمبر 2026

هذه المنظومة برنامج خاص وليس مفتوح المصدر، مرخّص لصالح
إدارة الخدمات الطبية العسكرية — دولة ليبيا

تحت رعاية وتطوير: مروان السيدي — Marwan Alsidi

أحكام الترخيص:
1) ملف الترخيص مشفر (AES-256-GCM) ولا يُفك إلا داخل التطبيق نفسه.
2) لا يحق لأي جهة أو فرد نسخ المشروع أو تعديله أو إعادة توزيعه،
   إلا لمطوّره أو لمن يحمل مفتاح المصدر الرسمي ممنوحاً منه.
3) مفتاح المصدر يُمنح حصرياً من المطوّر، ويُطلق داخل التطبيق
   بعد إدخال الرقم السري الخاص بمطوّره فقط.
4) أي تعديل على المشروع أو بناؤه من جديد يتطلب مفتاح المصدر؛
   والتعديل أو البناء بدون مفتاح رسمي يعدّ مخالفة لهذا الترخيص.
5) جميع الحقوق محفوظة © 2026 مروان السيدي — منظومة البيانات."""

def java_arr(b):
    return "{" + ", ".join(str(x if x < 128 else x - 256) for x in b) + "}"

def obfuscate(s, mask):
    raw = s.encode("utf-8")
    return bytes(raw[i] ^ mask[i % len(mask)] for i in range(len(raw)))

def main():
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    key = secrets.token_bytes(32)
    nonce = secrets.token_bytes(12)
    cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
    ct, tag = cipher.encrypt_and_digest(LICENSE_TEXT.encode("utf-8"))
    with open(OUT, "wb") as f:
        f.write(b"MLIC1" + nonce + ct + tag)
    print("license.dat:", os.path.getsize(OUT), "bytes")

    mask = secrets.token_bytes(16)
    print("\n--- License.java constants ---")
    print("LIC_MASK =", java_arr(mask))
    print("LIC_KEY  =", java_arr(bytes(key[i] ^ mask[i % len(mask)] for i in range(32))))
    print("SRC_ENC  =", java_arr(obfuscate(SRC_KEY, mask)))
    print("PIN_ENC  =", java_arr(obfuscate(SECRET_PIN, mask)))
    print("SRC_LEN  =", len(SRC_KEY.encode()), " PIN_LEN =", len(SECRET_PIN.encode()))

main()
