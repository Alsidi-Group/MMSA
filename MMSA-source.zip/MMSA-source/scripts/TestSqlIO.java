import java.io.*;
import java.util.*;

/** اختبار محلي لمنطق SqlIO و SheetIO (بدون أندرويد) */
public class TestSqlIO {

    static int pass = 0, fail = 0;

    static void eq(String name, Object got, Object want) {
        boolean ok = Objects.equals(got, want);
        if (ok) { pass++; }
        else { fail++; System.out.println("FAIL " + name + ": got=" + got + " want=" + want); }
    }

    public static void main(String[] args) throws Exception {
        // ===== 1) دورة كاملة: موظفون → SQL → قراءة =====
        List<Employee> emps = new ArrayList<>();
        Employee a = new Employee();
        a.d.put("empType", "عسكري");
        a.d.put("finNumber", "12345");
        a.d.put("rank", "نقيب");
        a.d.put("nationalId", "11920304051011");
        a.d.put("fullName", "علي حسن محمد O'Brien");
        a.d.put("unit", "المستشفى، قسم الجراحة");
        a.d.put("salary", "1200");
        emps.add(a);
        Employee b = new Employee();
        b.d.put("empType", "مدني");
        b.d.put("milNumber", "777");
        b.d.put("rank", "موظف");
        b.d.put("fullName", "سالم قدّور السلام");
        b.d.put("appointDate", "2015-03-01");
        emps.add(b);

        File f = new File("/tmp/test_mmsa.sql");
        SqlIO.writeSql(f, emps);
        String dump = new String(java.nio.file.Files.readAllBytes(f.toPath()), "UTF-8");
        eq("dump has insert", dump.contains("INSERT INTO employees"), true);
        eq("dump escapes quote", dump.contains("O''Brien"), true);

        SqlIO.SqlRows r;
        try (InputStream in = new FileInputStream(f)) { r = SqlIO.readSql(in); }
        eq("sql statements", r.statements, 2);
        eq("sql rows", r.rows.size(), 2);
        int iNat = keyIdx("nationalId"), iName = keyIdx("fullName"), iUnit = keyIdx("unit"),
                iFin = keyIdx("finNumber"), iMil = keyIdx("milNumber"), iApp = keyIdx("appointDate");
        eq("sql name quote", r.rows.get(0)[iName], "علي حسن محمد O'Brien");
        eq("sql unit comma", r.rows.get(0)[iUnit], "المستشفى، قسم الجراحة");
        eq("sql fin", r.rows.get(0)[iFin], "12345");
        eq("sql empty mil stays empty", r.rows.get(0)[iMil], "");
        eq("sql date", r.rows.get(1)[iApp], "2015-03-01");

        // ===== 2) SQL خارجي: أعمدة بترتيب مختلف + عمود مجهول + NULL =====
        String foreign = "CREATE TABLE employees (id INT, notes TEXT);\n"
                + "INSERT INTO `employees` (`nationalId`, `fullName`, `salary`, `notes`) VALUES\n"
                + "  ('11920304051011', 'سالم، قدور', 'O''Brien, آدم', NULL),\n"
                + "  ('999999999999', NULL, '900', 'ملاحظة');\n"
                + "INSERT INTO other (x) VALUES ('INSERT (1)');\n";
        File f2 = new File("/tmp/test_foreign.sql");
        Writer w = new OutputStreamWriter(new FileOutputStream(f2), "UTF-8");
        w.write(foreign); w.close();
        try (InputStream in = new FileInputStream(f2)) { r = SqlIO.readSql(in); }
        eq("foreign rows", r.rows.size(), 2);
        eq("foreign nat", r.rows.get(0)[iNat], "11920304051011");
        eq("foreign comma value", r.rows.get(0)[iName], "سالم، قدور");
        eq("foreign unknown col ignored", r.rows.get(0)[iFin], "");
        eq("foreign null col", r.rows.get(1)[iName], "");
        eq("fake insert in string ignored", r.rows.size(), 2);

        // ===== 3) SQL بلا أعمدة مسماة: الترتيب القياسي =====
        String std = "INSERT INTO employees VALUES (1, 'عسكري', '55', '', 'نقيب', '11920304051011', 'محمد', '', '', '', '', '', '', '', '', '', '', '');\n";
        File f3 = new File("/tmp/test_std.sql");
        Writer w3 = new OutputStreamWriter(new FileOutputStream(f3), "UTF-8");
        w3.write(std); w3.close();
        try (InputStream in = new FileInputStream(f3)) { r = SqlIO.readSql(in); }
        eq("std rows", r.rows.size(), 1);
        eq("std fin", r.rows.get(0)[iFin], "55");
        eq("std name", r.rows.get(0)[iName], "محمد");

        // ===== 4) دورة XLSX وCSV =====
        List<String[]> rows = new ArrayList<>();
        for (Employee e : emps) rows.add(e.exportRow());
        File fx = new File("/tmp/test_mmsa.xlsx");
        SheetIO.writeXlsx(fx, Employee.EXPORT_HEADERS, rows);
        List<String[]> back;
        try (InputStream in = new FileInputStream(fx)) { back = SheetIO.readXlsx(in); }
        eq("xlsx rows", back.size(), 3); // ترويسة + صفان
        eq("xlsx header", back.get(0)[0], Employee.EXPORT_HEADERS[0]);
        eq("xlsx value", back.get(1)[iName], "علي حسن محمد O'Brien");

        File fc = new File("/tmp/test_mmsa.csv");
        SheetIO.writeCsv(fc, Employee.EXPORT_HEADERS, rows);
        try (InputStream in = new FileInputStream(fc)) { back = SheetIO.readCsv(in); }
        eq("csv rows", back.size(), 3);
        eq("csv comma value", back.get(1)[iUnit], "المستشفى، قسم الجراحة");

        System.out.println("PASS=" + pass + " FAIL=" + fail);
        if (fail > 0) System.exit(1);
    }

    static int keyIdx(String k) {
        for (int i = 0; i < Employee.EXPORT_KEYS.length; i++)
            if (Employee.EXPORT_KEYS[i].equals(k)) return i;
        return -1;
    }
}
