package com.mmsa.records;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

/** اختبار محرك Excel/CSV على سطح المكتب (بدون أندرويد) */
public class TestSheetIO {

    public static void main(String[] args) throws Exception {
        File dir = new File("/home/z/my-project/work/sheettest");
        dir.mkdirs();
        String[] headers = Employee.EXPORT_HEADERS;
        List<String[]> rows = new ArrayList<>();

        Employee e = new Employee();
        e.id = 1;
        e.d.put("empType", "عسكري");
        e.d.put("finNumber", "12345");
        e.d.put("milNumber", "");
        e.d.put("rank", "نقيب");
        e.d.put("nationalId", "1122334455");
        e.d.put("fullName", "أحمد محمد علي الصديق");
        e.d.put("unit", "المستشفى العسكري");
        e.d.put("joinDate", "2021-03-15");
        e.d.put("appointDate", "2010-01-01");
        e.d.put("appointDecree", "2044");
        e.d.put("lastPromotion", "2023-06-20");
        e.d.put("dueDate", "2026-01-15");
        e.d.put("grade", "8");
        e.d.put("bankName", "مصرف الجمهورية");
        e.d.put("bankBranch", "فرع طرابلس");
        e.d.put("bankAccount", "5001234567");
        e.d.put("salary", "1250.50");
        rows.add(e.exportRow());

        // صف بحروف خاصة: فاصلة، اقتباس، سطر جديد، أرقام عربية
        Employee e2 = new Employee();
        e2.id = 2;
        e2.d.put("empType", "مدني");
        e2.d.put("finNumber", "77");
        e2.d.put("rank", "موظفة");
        e2.d.put("nationalId", "9988776655");
        e2.d.put("fullName", "سمية, \"الأمينة\"\nسالم");
        e2.d.put("unit", "الجهة - الفرع (الأول)");
        e2.d.put("joinDate", "2021-03-15");
        rows.add(e2.exportRow());

        File x = new File(dir, "test.xlsx");
        SheetIO.writeXlsx(x, headers, rows);
        File c = new File(dir, "test.csv");
        SheetIO.writeCsv(c, headers, rows);

        List<String[]> rx = SheetIO.readXlsx(new FileInputStream(x));
        List<String[]> rc = SheetIO.readCsv(new FileInputStream(c));
        // القارئ يُعيد صف العناوين + البيانات
        List<String[]> rxHead = rx.subList(0, 1);
        List<String[]> rxD = rx.subList(1, rx.size());
        List<String[]> rcD = rc.subList(1, rc.size());
        assertEquals(toList(headers), rxHead, "xlsx-headers");
        assertEquals(rows, rxD, "xlsx");
        assertEquals(rows, rcD, "csv");

        // فحوصات أدوات التحويل
        if (!Employee.toWestern("١٢٣٤٥").equals("12345")) throw new Exception("toWestern arabic failed");
        if (!Employee.digitsOnly("abc 1a2٣").equals("123")) throw new Exception("digitsOnly failed");
        if (!Employee.textOnly("أحمد 123 محمد").equals("أحمد  محمد")) throw new Exception("textOnly failed");
        if (!Employee.isoToDisp("2021-03-15").equals("15/03/2021")) throw new Exception("isoToDisp failed");
        if (!Employee.anyToIso("15/03/2021").equals("2021-03-15")) throw new Exception("anyToIso failed");
        if (!Employee.anyToIso("2021-03-15").equals("2021-03-15")) throw new Exception("anyToIso iso failed");
        if (Employee.anyToIso("كذا").length() != 0) throw new Exception("anyToIso invalid should be empty");
        if (cmp("1.0.0", "1.0.1") >= 0) throw new Exception("cmp failed");
        if (cmp("1.2.0", "1.1.9") <= 0) throw new Exception("cmp failed 2");
        if (cmp("1.0.0", "1.0.0") != 0) throw new Exception("cmp failed 3");

        System.out.println("ROUNDTRIP_OK xlsx rows=" + rx.size() + " csv rows=" + rc.size());
        System.out.println("UTILS_OK");
    }

    /** نسخة مطابقة من Updater.cmp للاختبار على سطح المكتب */
    static int cmp(String a, String b) {
        String[] A = a.trim().split("\\.");
        String[] B = b.trim().split("\\.");
        for (int i = 0; i < Math.max(A.length, B.length); i++) {
            int x = i < A.length ? Integer.parseInt(A[i].trim()) : 0;
            int y = i < B.length ? Integer.parseInt(B[i].trim()) : 0;
            if (x != y) return Integer.compare(x, y);
        }
        return 0;
    }

    static void assertEquals(List<String[]> a, List<String[]> b, String tag) throws Exception {
        if (a.size() != b.size())
            throw new Exception(tag + " row count mismatch " + a.size() + " vs " + b.size());
        for (int i = 0; i < a.size(); i++) {
            String[] ra = a.get(i), rb = b.get(i);
            if (ra.length != rb.length)
                throw new Exception(tag + " col count mismatch @row " + i);
            for (int j = 0; j < ra.length; j++)
                if (!ra[j].equals(rb[j]))
                    throw new Exception(tag + " value mismatch @row " + i + " col " + j
                            + ": [" + ra[j] + "] vs [" + rb[j] + "]");
        }
    }

    static List<String[]> toList(String[] arr) {
        List<String[]> l = new ArrayList<>();
        l.add(arr);
        return l;
    }
}
