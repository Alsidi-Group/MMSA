#!/usr/bin/env bash
# بناء APK يدوياً: aapt2 + javac + d8 + zipalign + apksigner
set -e
W=/home/z/my-project/work
S=$W/MMSA/app/src/main
JDK=$W/jdk
BT=$W/sdk/build-tools/34.0.0
PLAT=$W/sdk/platforms/android-34/android.jar
OUT=$W/build

rm -rf "$OUT"
mkdir -p "$OUT/gen" "$OUT/classes" "$OUT/dex"

echo "== aapt2 compile"
"$BT/aapt2" compile --dir "$S/res" -o "$OUT/res.zip"

echo "== aapt2 link"
"$BT/aapt2" link -o "$OUT/base.apk" -I "$PLAT" \
  --manifest "$S/AndroidManifest.xml" -R "$OUT/res.zip" \
  --java "$OUT/gen" --min-sdk-version 24 --target-sdk-version 34 \
  --version-code 3 --version-name 1.1.0 -A "$S/assets" --auto-add-overlay

echo "== javac"
find "$S/java" "$OUT/gen" -name '*.java' > "$OUT/sources.txt"
wc -l "$OUT/sources.txt"
"$JDK/bin/javac" -encoding UTF-8 --release 8 -Xlint:-options \
  -classpath "$PLAT" -d "$OUT/classes" @"$OUT/sources.txt"

echo "== d8"
find "$OUT/classes" -name '*.class' | xargs "$BT/d8" --release --lib "$PLAT" --min-api 24 --output "$OUT/dex"

echo "== package dex into apk"
(cd "$OUT/dex" && zip -q -j "$OUT/base.apk" classes.dex)

echo "== zipalign"
"$BT/zipalign" -f -p 4 "$OUT/base.apk" "$OUT/aligned.apk"

echo "== keystore"
KS=$W/mmsa-release.keystore
if [ ! -f "$KS" ]; then
  "$JDK/bin/keytool" -genkeypair -keystore "$KS" -alias mmsa -keyalg RSA -keysize 2048 \
    -validity 10950 -storepass MMSA2026key -keypass MMSA2026key \
    -dname "CN=Marwan Alsidi, OU=MMSA, O=Military Medical Services Administration, L=Tripoli, C=LY"
fi

echo "== apksigner sign"
"$BT/apksigner" sign --ks "$KS" --ks-pass pass:MMSA2026key --ks-key-alias mmsa \
  --key-pass pass:MMSA2026key --out "$OUT/MMSA-1.1.0.apk" "$OUT/aligned.apk"

echo "== verify"
"$BT/apksigner" verify --print-certs "$OUT/MMSA-1.1.0.apk"

echo "== badging"
"$BT/aapt2" dump badging "$OUT/MMSA-1.1.0.apk" | head -12

echo "BUILD_OK $OUT/MMSA-1.1.0.apk"
