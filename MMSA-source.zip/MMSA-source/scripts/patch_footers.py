#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ما بعد التوليد: تصحيح أرقام الصفحات (روماني/عربي) وإزالة pgNumType الفارغ من قسم الغلاف."""
import re
import shutil
import sys
import zipfile

path = sys.argv[1]
tmp = path + ".tmp"

with zipfile.ZipFile(path) as z:
    names = z.namelist()
    data = {n: z.read(n) for n in names}

doc = data["word/document.xml"].decode("utf-8")
rels = data["word/_rels/document.xml.rels"].decode("utf-8")

# خريطة rId -> ملف footer
rel_map = dict(re.findall(r'<Relationship[^>]*Id="(rId\d+)"[^>]*Target="(footer\d+\.xml)"', rels))
rel_map.update({rid: tgt for tgt, rid in re.findall(r'<Relationship[^>]*Target="(footer\d+\.xml)"[^>]*Id="(rId\d+)"', rels)})

# الأقسام بترتيبها: استخرج footerReference الافتراضي لكل sectPr
sect_footers = []
for sect in re.findall(r"<w:sectPr[ >].*?</w:sectPr>", doc, flags=re.S):
    m = re.search(r'<w:footerReference w:type="default" r:id="(rId\d+)"', sect)
    sect_footers.append(rel_map.get(m.group(1)) if m else None)
print("sections footers:", sect_footers)

def patch_footer(fname, fmt):
    key = "word/" + fname
    if key not in data:
        return
    xml = data[key].decode("utf-8")
    xml = xml.replace("> PAGE ", "> PAGE \\* %s \\* MERGEFORMAT " % fmt)
    xml = xml.replace('>PAGE<', '> PAGE \\* %s \\* MERGEFORMAT <' % fmt)
    data[key] = xml.encode("utf-8")

# القسم الثاني (المحتويات) = روماني، الثالث (المتن) = عربي
if len(sect_footers) >= 3:
    if sect_footers[1]:
        patch_footer(sect_footers[1], "ROMAN")
    if sect_footers[2]:
        patch_footer(sect_footers[2], "arabic")

# إزالة pgNumType الفارغ من قسم الغلاف فقط (أول sectPr)
sections = re.findall(r"<w:sectPr[ >].*?</w:sectPr>", doc, flags=re.S)
if sections and "<w:pgNumType/>" in sections[0]:
    fixed = sections[0].replace("<w:pgNumType/>", "")
    doc = doc.replace(sections[0], fixed, 1)

data["word/document.xml"] = doc.encode("utf-8")

with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
    for n in names:
        z.writestr(n, data[n])
shutil.move(tmp, path)
print("FOOTER_PATCH_OK")
