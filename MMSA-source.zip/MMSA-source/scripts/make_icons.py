#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Generate placeholder emblem + launcher icons for MMSA app.
Emblem: dark-green disc, gold double ring, gold laurel branches,
gold star, white medical cross. Replaced later by the real logo
(either res/drawable-nodpi/logo.png or in-app import)."""
import os
import math
from PIL import Image, ImageDraw

RES = "/home/z/my-project/work/MMSA/app/src/main/res"
GOLD = (201, 162, 39, 255)
GOLD_L = (227, 192, 92, 255)
GREEN = (31, 92, 61, 255)
GREEN_D = (20, 64, 42, 255)
WHITE = (255, 255, 255, 255)

os.makedirs(os.path.join(RES, "drawable-nodpi"), exist_ok=True)
for d in ["mipmap-mdpi", "mipmap-hdpi", "mipmap-xhdpi", "mipmap-xxhdpi", "mipmap-xxxhdpi", "mipmap-anydpi-v26"]:
    os.makedirs(os.path.join(RES, d), exist_ok=True)


def star(draw, cx, cy, R, r, fill):
    pts = []
    for i in range(10):
        ang = -math.pi / 2 + i * math.pi / 5
        rad = R if i % 2 == 0 else r
        pts.append((cx + rad * math.cos(ang), cy + rad * math.sin(ang)))
    draw.polygon(pts, fill=fill)


def leaf_layer():
    img = Image.new("RGBA", (72, 30), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.ellipse([2, 4, 70, 26], fill=GOLD)
    return img


LEAF = leaf_layer()


def emblem(size=1024):
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    cx = size / 2
    s = size / 1024.0
    # outer gold ring + disc
    d.ellipse([60 * s, 60 * s, 964 * s, 964 * s], outline=GOLD, width=int(38 * s))
    d.ellipse([100 * s, 100 * s, 924 * s, 924 * s], fill=GREEN)
    d.ellipse([156 * s, 156 * s, 868 * s, 868 * s], outline=GOLD_L, width=int(10 * s))
    # laurel stems (bottom arcs) + leaves
    R = 350 * s
    for start, end in [(105, 185), (355, 435)]:  # PIL angles: CW, 0=east
        bbox = [cx - R, cx - R, cx + R, cx + R]
        d.arc(bbox, start=start, end=end, fill=GOLD, width=int(9 * s))
        for a in range(start + 4, end - 2, 13):
            rad = math.radians(a)
            px = cx + R * math.cos(rad)
            py = cx + R * math.sin(rad)
            lf = LEAF.resize((int(74 * s), int(30 * s)))
            lf = lf.rotate(-(a - 90), expand=True, resample=Image.BICUBIC)
            img.alpha_composite(lf, (int(px - lf.width / 2), int(py - lf.height / 2)))
    # gold star (top)
    star(d, cx, 285 * s, 78 * s, 31 * s, GOLD)
    # white medical cross
    rad = int(26 * s)
    d.rounded_rectangle([465 * s, 372 * s, 559 * s, 668 * s], radius=rad, fill=WHITE)
    d.rounded_rectangle([358 * s, 465 * s, 666 * s, 559 * s], radius=rad, fill=WHITE)
    return img


def rounded_bg(size, radius):
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([0, 0, size - 1, size - 1], radius=radius, fill=GREEN_D)
    return img


EMB = emblem(1024)

# in-app / print logo (transparent bg)
EMB.resize((512, 512), Image.LANCZOS).save(os.path.join(RES, "drawable-nodpi", "logo.png"))

DENS = {"mdpi": 1.0, "hdpi": 1.5, "xhdpi": 2.0, "xxhdpi": 3.0, "xxxhdpi": 4.0}
for den, k in DENS.items():
    base = int(48 * k)
    # legacy launcher (square, rounded)
    sq = rounded_bg(1024, 210)
    e2 = EMB.resize((900, 900), Image.LANCZOS)
    sq.alpha_composite(e2, (62, 62))
    sq.resize((base, base), Image.LANCZOS).save(os.path.join(RES, f"mipmap-{den}", "ic_launcher.png"))
    # round launcher
    EMB.resize((base, base), Image.LANCZOS).save(os.path.join(RES, f"mipmap-{den}", "ic_launcher_round.png"))
    # adaptive foreground (108dp grid, emblem ~60% safe zone)
    fg_size = int(108 * k)
    fg = Image.new("RGBA", (1024, 1024), (0, 0, 0, 0))
    e3 = EMB.resize((640, 640), Image.LANCZOS)
    fg.alpha_composite(e3, (192, 192))
    fg.resize((fg_size, fg_size), Image.LANCZOS).save(os.path.join(RES, f"mipmap-{den}", "ic_launcher_foreground.png"))

# adaptive icon xmls
AD = '<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n  <background android:drawable="@color/icon_bg"/>\n  <foreground android:drawable="@mipmap/ic_launcher_foreground"/>\n</adaptive-icon>\n'
with open(os.path.join(RES, "mipmap-anydpi-v26", "ic_launcher.xml"), "w") as f:
    f.write(AD)
with open(os.path.join(RES, "mipmap-anydpi-v26", "ic_launcher_round.xml"), "w") as f:
    f.write(AD)

# preview for the user
os.makedirs("/home/z/my-project/work/preview", exist_ok=True)
EMB.resize((512, 512), Image.LANCZOS).save("/home/z/my-project/work/preview/logo_placeholder.png")
print("icons generated OK")
