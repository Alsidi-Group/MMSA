#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""معالجة الشعار الرسمي المرفوع: إزالة الخلفية البيضاء الخارجية فقط
(Flood fill من الزوايا — الأبيض الداخلي المحفوظ لأنه محاط بالخط الرمادي)،
قص الحواف، ثم توليد أيقونات التشغيل والشعار الداخلي للتطبيق."""
import os
from PIL import Image, ImageChops, ImageDraw, ImageFilter

SRC = "/home/z/my-project/upload/1795111820634.jpg"
RES = "/home/z/my-project/work/MMSA/app/src/main/res"
PREVIEW = "/home/z/my-project/work/preview"

os.makedirs(PREVIEW, exist_ok=True)

# ---------- 1) قص وإزالة الخلفية ----------
src = Image.open(SRC).convert("RGB")
print("source size:", src.size)

im = src.copy()
for xy in [(0, 0), (im.width - 1, 0), (0, im.height - 1), (im.width - 1, im.height - 1)]:
    ImageDraw.floodfill(im, xy, (255, 0, 255), thresh=60)

# قناع الشفافية: الماجنتا = خلفية خارجية فقط
solid = Image.new("RGB", im.size, (255, 0, 255))
diff = ImageChops.difference(im, solid)
alpha = diff.convert("L").point(lambda v: 0 if v <= 8 else 255)
# تنعيم الحافة
alpha = alpha.filter(ImageFilter.GaussianBlur(0.8))

emblem = src.convert("RGBA")
emblem.putalpha(alpha)

bbox = alpha.getbbox()
print("content bbox:", bbox)
emblem = emblem.crop(bbox)

# مربّع مع هوامش متساوية
w, h = emblem.size
side = max(w, h)
pad = int(side * 0.06)
canvas = Image.new("RGBA", (side + pad * 2, side + pad * 2), (0, 0, 0, 0))
canvas.paste(emblem, (pad + (side - w) // 2, pad + (side - h) // 2), emblem)
emblem = canvas

# ---------- 2) شعار التطبيق وصفحة الطباعة ----------
os.makedirs(os.path.join(RES, "drawable-nodpi"), exist_ok=True)
emblem.resize((512, 512), Image.LANCZOS).save(os.path.join(RES, "drawable-nodpi", "logo.png"))

# ---------- 3) أيقونات التشغيل ----------
GREEN_D = (20, 64, 42, 255)
DENS = {"mdpi": 1.0, "hdpi": 1.5, "xhdpi": 2.0, "xxhdpi": 3.0, "xxxhdpi": 4.0}
BIG = emblem.resize((1024, 1024), Image.LANCZOS)

for den, k in DENS.items():
    base = int(48 * k)
    # أيقونة مربعة (إصدارات أقدم من 8): خلفية خضراء داكنة + الشعار الدائري
    sq = Image.new("RGBA", (1024, 1024), (0, 0, 0, 0))
    d = ImageDraw.Draw(sq)
    d.rounded_rectangle([0, 0, 1023, 1023], radius=210, fill=GREEN_D)
    e2 = BIG.resize((880, 880), Image.LANCZOS)
    sq.alpha_composite(e2, (72, 72))
    sq.resize((base, base), Image.LANCZOS).save(os.path.join(RES, f"mipmap-{den}", "ic_launcher.png"))
    # أيقونة دائرية: الشعار كما هو (دائري أصلاً)
    BIG.resize((base, base), Image.LANCZOS).save(os.path.join(RES, f"mipmap-{den}", "ic_launcher_round.png"))
    # الطبقة الأمامية للأيقونة المتكيفة (108dp، الشعار داخل المنطقة الآمنة)
    fg = Image.new("RGBA", (1024, 1024), (0, 0, 0, 0))
    e3 = BIG.resize((660, 660), Image.LANCZOS)
    fg.alpha_composite(e3, (182, 182))
    fg.resize((int(108 * k), int(108 * k)), Image.LANCZOS).save(
        os.path.join(RES, f"mipmap-{den}", "ic_launcher_foreground.png"))

# خلفية الأيقونة المتكيفة: أبيض (الشعار مصمم على أبيض)
with open(os.path.join(RES, "values", "strings.xml"), "w", encoding="utf-8") as f:
    f.write('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n'
            '    <string name="app_name">منظومة البيانات</string>\n'
            '    <color name="icon_bg">#FFFFFF</color>\n</resources>\n')

# ---------- 4) نسخة معاينة للمستخدم ----------
emblem.resize((512, 512), Image.LANCZOS).save(os.path.join(PREVIEW, "logo_official.png"))
print("official logo + icons generated OK")
