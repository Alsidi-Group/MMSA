package com.mmsa.records;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

/** نموذج بيانات الموظف + تعريفات الحقول والرتب وأدوات التحويل */
public class Employee {
    public int id;
    public HashMap<String, String> d = new HashMap<>();
    public long createdAt, updatedAt;

    // أنواع الإدخال
    public static final int K_NUM = 0;   // أرقام فقط
    public static final int K_TEXT = 1;  // نص فقط
    public static final int K_DATE = 2;  // تاريخ فقط
    public static final int K_FREE = 3;  // أرقام أو نص

    // أعمدة قاعدة البيانات (بنفس ترتيب الشيت)
    public static final String[] COLS = {
            "empType", "finNumber", "milNumber", "rank", "nationalId", "fullName", "unit",
            "joinDate", "appointDate", "appointDecree", "lastPromotion", "dueDate", "grade",
            "bankName", "bankBranch", "bankAccount", "salary"
    };

    // تسميات العرض/الطباعة/التصدير بترتيب الشيت (16 بنداً)
    public static final String[][] LABELS = {
            {"finNumber", "رقم الوظيفي (المالي)"},
            {"milNumber", "الرقم العسكري"},
            {"rank", "الرتبة"},
            {"nationalId", "الرقم الوطني"},
            {"fullName", "الاسم الرباعي"},
            {"unit", "الجهة التابع لها"},
            {"joinDate", "تاريخ الالتحاق بالوحدة التابع لها الآن"},
            {"appointDate", "تاريخ التعيين"},
            {"appointDecree", "رقم قرار التعيين"},
            {"lastPromotion", "تاريخ آخر قرار ترقية"},
            {"dueDate", "تاريخ الاستحقاق"},
            {"grade", "الدرجة الحالية"},
            {"bankName", "اسم المصرف"},
            {"bankBranch", "فرع المصرف"},
            {"bankAccount", "رقم الحساب المصرفي"},
            {"salary", "قيمة المرتب الشهري"},
    };

    // أعمدة التصدير (التسلسل + الصفة + البنود الـ16)
    public static final String[] EXPORT_HEADERS = {
            "التسلسل", "الصفة", "رقم الوظيفي (المالي)", "الرقم العسكري", "الرتبة", "الرقم الوطني",
            "الاسم الرباعي", "الجهة التابع لها", "تاريخ الالتحاق بالوحدة التابع لها الآن", "تاريخ التعيين",
            "رقم قرار التعيين", "تاريخ آخر قرار ترقية", "تاريخ الاستحقاق", "الدرجة الحالية",
            "اسم المصرف", "فرع المصرف", "رقم الحساب المصرفي", "قيمة المرتب الشهري"
    };
    public static final String[] EXPORT_KEYS = {
            "id", "empType", "finNumber", "milNumber", "rank", "nationalId", "fullName", "unit",
            "joinDate", "appointDate", "appointDecree", "lastPromotion", "dueDate", "grade",
            "bankName", "bankBranch", "bankAccount", "salary"
    };

    public static final String TYPE_MIL = "عسكري";
    public static final String TYPE_CIV = "مدني";
    public static final String ID_FIN = "رقم الوظيفي (المالي)";
    public static final String ID_MIL = "الرقم العسكري";

    // الرتب العسكرية كما وردت في الطلب (قائمة موسعة)
    public static final String[] RANKS_MIL = {
            "جندي", "جندي أول", "نائب عريف", "عريف", "رئيس عرفة سرية", "رئيس عرفة وحدة",
            "ملازم ثان", "ملازم أول", "نقيب", "مقدم", "عقيد", "عميد", "لواء", "فريق",
            "فريق أول", "مشير"
    };
    // رتب المدنيين
    public static final String[] RANKS_CIV = {"موظف", "موظفة"};

    public String val(String key) {
        String v = d.get(key);
        return v == null ? "" : v;
    }

    public static String labelOf(String key) {
        for (String[] p : LABELS) if (p[0].equals(key)) return p[1];
        return key;
    }

    public String displayValue(String key, boolean dashForEmpty) {
        String v = val(key);
        if (key.endsWith("Date")) v = isoToDisp(v);
        if (dashForEmpty && (v == null || v.trim().isEmpty())) return "—";
        return v == null ? "" : v;
    }

    /** تحويل الأرقام العربية/الفارسية إلى أرقام لاتينية */
    public static String toWestern(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder();
        for (char ch : s.toCharArray()) {
            if (ch >= '\u0660' && ch <= '\u0669') b.append((char) (ch - '\u0660' + '0'));
            else if (ch >= '\u06F0' && ch <= '\u06F9') b.append((char) (ch - '\u06F0' + '0'));
            else b.append(ch);
        }
        return b.toString();
    }

    /** أرقام فقط (بعد التعريب) */
    public static String digitsOnly(String s) {
        StringBuilder b = new StringBuilder();
        for (char ch : toWestern(s).toCharArray()) if (ch >= '0' && ch <= '9') b.append(ch);
        return b.toString();
    }

    /** نص فقط: حروف ومسافات وعلامات أساسية، بدون أرقام */
    public static String textOnly(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder();
        for (char ch : toWestern(s).toCharArray()) {
            boolean ok = Character.isLetter(ch) || ch == ' ' || ch == '.' || ch == '-'
                    || ch == '/' || ch == '(' || ch == ')' || ch == '\'' || ch == '\u0640';
            if (ok) b.append(ch);
        }
        return b.toString();
    }

    private static final SimpleDateFormat ISO = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
    private static final SimpleDateFormat DISP = new SimpleDateFormat("dd/MM/yyyy", Locale.US);

    /** ISO yyyy-MM-dd إلى dd/MM/yyyy للعرض */
    public static String isoToDisp(String iso) {
        if (iso == null || iso.trim().isEmpty()) return "";
        try {
            Date dt = ISO.parse(iso.trim());
            return DISP.format(dt);
        } catch (ParseException e) {
            return iso.trim();
        }
    }

    /** تحويل ISO yyyy-MM-dd إلى كائن تاريخ */
    public static Date parseIso(String iso) throws ParseException {
        return ISO.parse(iso);
    }

    /** dd/MM/yyyy أو yyyy-MM-dd إلى ISO للتخزين، أو "" إن كانت غير صالحة */
    public static String anyToIso(String s) {
        if (s == null) return "";
        s = s.trim();
        if (s.isEmpty()) return "";
        try {
            Date dt = DISP.parse(s);
            return ISO.format(dt);
        } catch (ParseException ignored) {
        }
        try {
            Date dt = ISO.parse(s);
            return ISO.format(dt);
        } catch (ParseException ignored) {
        }
        return "";
    }

    /** صف تصدير واحد بترتيب الشيت */
    public String[] exportRow() {
        String[] row = new String[EXPORT_KEYS.length];
        for (int i = 0; i < EXPORT_KEYS.length; i++) {
            String k = EXPORT_KEYS[i];
            if (k.equals("id")) row[i] = String.valueOf(id);
            else if (k.equals("empType")) row[i] = val("empType");
            else row[i] = displayValue(k, false);
        }
        return row;
    }
}
