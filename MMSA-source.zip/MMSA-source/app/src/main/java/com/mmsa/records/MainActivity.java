package com.mmsa.records;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

/** الواجهة الرئيسية: بطاقة الشعار والاسم + شرائح الإحصاء + بحث بأيقونات + أدوات سفلية */
public class MainActivity extends BaseActivity {

    private EditText fName, fNat, fNum;
    private Spinner sIdType;
    private LinearLayout resultsBox;
    private TextView resTitle, vAll, vMil, vCiv;
    private ArrayList<Employee> results = new ArrayList<>();
    private boolean autoChecked = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        ScrollView sc = new ScrollView(this);
        sc.setFillViewport(true);
        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(16);
        inner.setPadding(pad, pad, pad, dp(20));
        sc.addView(inner, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.addView(sc, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // ===== بطاقة البطل: الشعار داخل دائرة بيضاء + الاسم والجهة =====
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setGravity(Gravity.CENTER);
        hero.setBackground(th.gradient(this, 26, th.primary, th.primaryDark));
        hero.setPadding(pad, dp(20), pad, dp(18));
        hero.setElevation(dp(5));

        ImageView logo = new ImageView(this);
        Bitmap lg = Theme.loadLogo(this);
        logo.setImageBitmap(lg);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        GradientDrawable disc = new GradientDrawable();
        disc.setShape(GradientDrawable.OVAL);
        disc.setColor(0xFFFFFFFF);
        logo.setBackground(disc);
        int pp = dp(6);
        logo.setPadding(pp, pp, pp, pp);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(92), dp(92));
        lp.gravity = Gravity.CENTER_HORIZONTAL;
        hero.addView(logo, lp);

        TextView title = th.text(this, "منظومة البيانات", 22, th.onPrimary, true);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(10), 0, dp(2));
        hero.addView(title, match());

        TextView subtitle = th.text(this, "إدارة الخدمات الطبية العسكرية", 13.5f,
                Theme.blend(th.onPrimary, th.primary, 0.18f), false);
        subtitle.setGravity(Gravity.CENTER);
        hero.addView(subtitle, match());

        TextView ver = th.text(this, "الإصدار " + Updater.VERSION_NAME, 11,
                Theme.blend(th.onPrimary, th.primary, 0.30f), true);
        ver.setGravity(Gravity.CENTER);
        ver.setPadding(0, dp(8), 0, 0);
        hero.addView(ver, match());

        inner.addView(hero, matchM(12));

        // ===== شرائح الإحصاء =====
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        cp.setMargins(dp(3), 0, dp(3), 0);
        vAll = addStatChip(chips, "people", "الكل", "0", cp);
        vMil = addStatChip(chips, "badge", "عسكري", "0", cp);
        vCiv = addStatChip(chips, "person", "مدني", "0", cp);
        inner.addView(chips, matchM(12));

        // ===== بطاقة البحث =====
        LinearLayout card = th.card(this, 22, 16);
        inner.addView(card, matchM(12));
        card.addView(th.sectionHeader(this, "search", "البحث عن موظف (خانة واحدة فقط)"), matchM(10));

        card.addView(th.label(this, "الاسم الرباعي"), match());
        fName = th.field(this, Employee.K_TEXT, "اكتب الاسم الرباعي أو جزءاً منه", "person");
        card.addView(fName, matchM(8));

        card.addView(th.label(this, "الرقم الوطني (أرقام فقط)"), match());
        fNat = th.field(this, Employee.K_NUM, "أرقام فقط", "id");
        card.addView(fNat, matchM(8));

        card.addView(th.label(this, "رقم الوظيفي (المالي) أو الرقم العسكري"), match());
        LinearLayout numRow = new LinearLayout(this);
        numRow.setOrientation(LinearLayout.HORIZONTAL);
        numRow.setGravity(Gravity.CENTER_VERTICAL);
        sIdType = th.spinner(this, new String[]{Employee.ID_FIN, Employee.ID_MIL});
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 0.42f);
        sp.rightMargin = dp(8);
        numRow.addView(th.spinnerIconed(this, sIdType, "badge"), sp);
        fNum = th.field(this, Employee.K_NUM, "أرقام فقط", "badge");
        numRow.addView(fNum, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 0.58f));
        card.addView(numRow, matchM(12));

        LinearLayout br = new LinearLayout(this);
        br.setOrientation(LinearLayout.HORIZONTAL);
        Button search = th.bigButton(this, "بحث", "search", true);
        Button clear = th.button(this, "مسح", false);
        br.addView(search, half());
        br.addView(clear, half());
        search.setOnClickListener(v -> doSearch());
        clear.setOnClickListener(v -> {
            fName.setText("");
            fNat.setText("");
            fNum.setText("");
            results.clear();
            renderResults();
        });
        card.addView(br, match());

        // ===== نتائج البحث =====
        resTitle = th.text(this, "", 13.5f, th.text, true);
        resTitle.setPadding(dp(4), dp(6), dp(4), dp(8));
        resultsBox = new LinearLayout(this);
        resultsBox.setOrientation(LinearLayout.VERTICAL);
        inner.addView(resTitle, match());
        inner.addView(resultsBox, match());
        renderResults();

        // ===== شريط الأدوات السفلي =====
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.VERTICAL);
        bar.setBackgroundColor(th.card);
        bar.setElevation(dp(10));
        int bp = dp(14);
        bar.setPadding(bp, dp(12), bp, dp(12));

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        Button add = th.bigButton(this, "إدخال بيانات جديد", "plus", true);
        Button print = th.bigButton(this, "الطباعة A4", "print", false);
        row1.addView(add, half());
        row1.addView(print, half());
        add.setOnClickListener(v ->
                startActivity(new Intent(this, FormActivity.class)));
        print.setOnClickListener(v -> printTool());
        bar.addView(row1, matchM(10));

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tp.setMargins(dp(3), 0, dp(3), 0);
        row2.addView(th.tileButton(this, "عرض الكل", "list", () ->
                startActivity(new Intent(this, ListActivity.class))), tp);
        row2.addView(th.tileButton(this, "الإحصائيات", "stats", () ->
                startActivity(new Intent(this, StatsActivity.class))), tp);
        row2.addView(th.tileButton(this, "أدوات البيانات", "tools", () ->
                startActivity(new Intent(this, ToolsActivity.class))), tp);
        row2.addView(th.tileButton(this, "حول التطبيق", "info", () ->
                startActivity(new Intent(this, AboutActivity.class))), tp);
        bar.addView(row2, match());

        page("الرئيسية", body, bar);
    }

    /** شريحة إحصاء بأيقونة وقيمة رقمية — تُعيد مرجع القيمة للتحديث لاحقاً */
    private TextView addStatChip(LinearLayout parent, String icon, String title, String val,
                                 LinearLayout.LayoutParams params) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER);
        l.setBackground(th.box(this, 16, th.fieldBg, th.line, 1f));
        l.setPadding(dp(6), dp(10), dp(6), dp(10));
        ImageView iv = new ImageView(this);
        iv.setImageDrawable(th.icon(this, icon, th.primary, 18));
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        l.addView(iv, new LinearLayout.LayoutParams(dp(22), dp(22)));
        TextView t = th.text(this, title, 11.5f, th.sub, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(4), 0, 0);
        l.addView(t, match());
        TextView v = th.text(this, val, 15, th.text, true);
        v.setGravity(Gravity.CENTER);
        v.setPadding(0, dp(2), 0, 0);
        l.addView(v, match());
        parent.addView(l, params);
        return v;
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshCounts();
        // فحص التحديثات تلقائياً مرة واحدة لكل فتح للتطبيق (عند توفر الإنترنت فقط)
        if (!autoChecked) {
            autoChecked = true;
            Updater.autoCheck(this);
        }
    }

    private void refreshCounts() {
        Db db = Db.get(this);
        int n = db.count();
        int mil = db.countType(Employee.TYPE_MIL);
        int civ = db.countType(Employee.TYPE_CIV);
        if (vAll != null) vAll.setText(String.valueOf(n));
        if (vMil != null) vMil.setText(String.valueOf(mil));
        if (vCiv != null) vCiv.setText(String.valueOf(civ));
    }

    /** البحث في خانة واحدة فقط: الاسم أو الرقم الوطني أو المالي/العسكري */
    private void doSearch() {
        String name = fName.getText().toString().trim();
        String nat = Employee.digitsOnly(fNat.getText().toString());
        String num = Employee.digitsOnly(fNum.getText().toString());
        int filled = 0;
        if (!name.isEmpty()) filled++;
        if (!nat.isEmpty()) filled++;
        if (!num.isEmpty()) filled++;
        if (filled == 0) {
            toast("اكتب بيانات البحث في خانة واحدة");
            return;
        }
        if (filled > 1) {
            toast("يمكن البحث في خانة واحدة فقط — امسح الخانات الأخرى");
            return;
        }
        Db db = Db.get(this);
        results = !name.isEmpty() ? db.searchName(name)
                : !nat.isEmpty() ? db.searchByCol("nationalId", nat)
                : db.searchByCol(sIdType.getSelectedItemPosition() == 0
                        ? "finNumber" : "milNumber", num);
        renderResults();
    }

    private void renderResults() {
        resultsBox.removeAllViews();
        resTitle.setText(results.isEmpty()
                ? "نتائج البحث"
                : "نتائج البحث (" + results.size() + ")");
        if (results.isEmpty()) {
            TextView t = th.text(this, "لا توجد نتائج — استخدم زر البحث بالأعلى، أو أضف موظفاً جديداً",
                    13, th.sub, false);
            t.setPadding(dp(4), dp(8), dp(4), dp(8));
            resultsBox.addView(t);
            return;
        }
        for (final Employee e : results) {
            resultsBox.addView(employeeCard(e));
        }
    }

    /** بطاقة موظف: شارة دائرية + الاسم + شريحة الرتبة + الأرقام */
    private LinearLayout employeeCard(Employee e) {
        LinearLayout row = th.card(this, 18, 12);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        ImageView av = new ImageView(this);
        av.setImageDrawable(th.icon(this, "person", th.onPrimary, 22));
        av.setScaleType(ImageView.ScaleType.FIT_CENTER);
        av.setBackground(th.gradient(this, 20, th.primary, th.primaryDark));
        av.setPadding(dp(9), dp(9), dp(9), dp(9));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(dp(44), dp(44));
        ap.rightMargin = dp(10);
        row.addView(av, ap);

        LinearLayout tx = new LinearLayout(this);
        tx.setOrientation(LinearLayout.VERTICAL);
        TextView name = th.text(this, e.displayValue("fullName", false), 15, th.text, true);
        tx.addView(name, matchM(2));
        String nums = "";
        if (!e.val("nationalId").isEmpty()) nums += "الوطني: " + e.val("nationalId");
        if (!e.val("finNumber").isEmpty())
            nums += (nums.isEmpty() ? "" : " • ") + "المالي: " + e.val("finNumber");
        if (!e.val("milNumber").isEmpty())
            nums += (nums.isEmpty() ? "" : " • ") + "العسكري: " + e.val("milNumber");
        TextView sub = th.text(this, nums.isEmpty() ? "—" : nums, 12, th.sub, false);
        tx.addView(sub, match());
        row.addView(tx, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView rank = th.chip(this, e.displayValue("rank", true), th.fieldBg, th.primary);
        row.addView(rank, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        row.setOnClickListener(v -> {
            Intent i = new Intent(this, DetailsActivity.class);
            i.putExtra("id", e.id);
            startActivity(i);
        });
        return row;
    }

    /** أداة العرض في وضع الطباعة A4: نتيجة واحدة → عرض مباشر، وإلا اختر من القائمة */
    private void printTool() {
        if (results.size() == 1) {
            Intent i = new Intent(this, PrintPreviewActivity.class);
            i.putExtra("id", results.get(0).id);
            startActivity(i);
        } else {
            Intent i = new Intent(this, ListActivity.class);
            i.putExtra("pick", true);
            startActivity(i);
        }
    }
}
