package com.mmsa.records;

import android.app.DatePickerDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

/** نظام التصميم UI/UX: 4 ثيمات + مصنع مكوّنات + أيقونات مرسومة + حقول مقيّدة بأيقونات */
public class Theme {

    public static final String[] THEME_NAMES = {"عسكري أخضر", "كحلي رسمي", "رملي صحراوي", "ليلي داكن"};

    public int primary, primaryDark, accent, bg, card, text, sub, onPrimary, danger, fieldBg, line;

    private void set(int t) {
        if (t == 0) { // عسكري أخضر
            primary = 0xFF1F5C3D; primaryDark = 0xFF14402A; accent = 0xFFC9A227;
            bg = 0xFFF1F4EE; card = 0xFFFFFFFF; text = 0xFF17251C; sub = 0xFF5A6B5D;
            onPrimary = 0xFFFFFFFF; danger = 0xFFB3261E; fieldBg = 0xFFF7F9F4; line = 0xFFD7DFD6;
        } else if (t == 1) { // كحلي رسمي
            primary = 0xFF1F3A5F; primaryDark = 0xFF152840; accent = 0xFFC9A227;
            bg = 0xFFF0F3F8; card = 0xFFFFFFFF; text = 0xFF141E2C; sub = 0xFF5A6B80;
            onPrimary = 0xFFFFFFFF; danger = 0xFFB3261E; fieldBg = 0xFFF6F8FB; line = 0xFFD5DCE6;
        } else if (t == 2) { // رملي صحراوي
            primary = 0xFF9C7A3C; primaryDark = 0xFF6E5628; accent = 0xFF1F5C3D;
            bg = 0xFFF8F3E9; card = 0xFFFFFFFF; text = 0xFF2A2416; sub = 0xFF7A6B4E;
            onPrimary = 0xFFFFFFFF; danger = 0xFFB3261E; fieldBg = 0xFFFBF7EE; line = 0xFFE2D8C2;
        } else { // ليلي داكن
            primary = 0xFF2E7D4F; primaryDark = 0xFF1B5E38; accent = 0xFFC9A227;
            bg = 0xFF161616; card = 0xFF212121; text = 0xFFEDEDED; sub = 0xFFA0A0A0;
            onPrimary = 0xFFFFFFFF; danger = 0xFFEF5350; fieldBg = 0xFF2B2B2B; line = 0xFF3C3C3C;
        }
    }

    public static int index(Context c) {
        int i = c.getSharedPreferences("mmsa", Context.MODE_PRIVATE).getInt("theme", 0);
        if (i < 0 || i > 3) i = 0;
        return i;
    }

    public static void save(Context c, int i) {
        c.getSharedPreferences("mmsa", Context.MODE_PRIVATE).edit().putInt("theme", i).apply();
    }

    public static Theme of(Context c) {
        Theme t = new Theme();
        t.set(index(c));
        return t;
    }

    public static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    /** فرض اللغة العربية على السياق */
    public static Context arabic(Context c) {
        java.util.Locale ar = new java.util.Locale("ar");
        android.content.res.Configuration cfg =
                new android.content.res.Configuration(c.getResources().getConfiguration());
        cfg.setLocale(ar);
        return c.createConfigurationContext(cfg);
    }

    // ---------- نصوص ----------

    public TextView text(Context c, String s, float sizeSp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sizeSp);
        t.setTextColor(color);
        t.setTypeface(bold ? Typeface.create("sans-serif-medium", Typeface.BOLD) : Typeface.DEFAULT);
        return t;
    }

    public TextView label(Context c, String s) {
        TextView t = text(c, s, 13, sub, true);
        t.setPadding(dp(c, 2), dp(c, 10), dp(c, 2), dp(c, 4));
        return t;
    }

    // ---------- أشكال وخلفيات ----------

    public GradientDrawable box(Context c, float radiusDp, int fill, int strokeColor, float strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.RECTANGLE);
        g.setCornerRadius(dp(c, radiusDp));
        g.setColor(fill);
        if (strokeColor != 0) g.setStroke(Math.max(1, dp(c, strokeDp)), strokeColor);
        return g;
    }

    /** خلفية متدرجة للأزرار الرئيسية والرأس */
    public GradientDrawable gradient(Context c, float radiusDp, int c1, int c2) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{c1, blend(c1, c2, 0.45f), c2});
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    public static int blend(int a, int b, float f) {
        int ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int br = (b >> 16) & 0xFF, bg2 = (b >> 8) & 0xFF, bb = b & 0xFF;
        int r = Math.round(ar + (br - ar) * f), g2 = Math.round(ag + (bg2 - ag) * f),
                bl = Math.round(ab + (bb - ab) * f);
        return 0xFF000000 | (r << 16) | (g2 << 8) | bl;
    }

    public LinearLayout card(Context c, float radiusDp) {
        return card(c, radiusDp, 14);
    }

    public LinearLayout card(Context c, float radiusDp, int paddingDp) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(box(c, radiusDp, card, line, 1f));
        int p = dp(c, paddingDp);
        l.setPadding(p, p, p, p);
        l.setElevation(dp(c, 3));
        return l;
    }

    /** شريحة pill صغيرة */
    public TextView chip(Context c, String s, int bg, int fg) {
        TextView t = text(c, s, 12, fg, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(box(c, 18, bg, 0, 0));
        t.setPadding(dp(c, 12), dp(c, 5), dp(c, 12), dp(c, 5));
        return t;
    }

    /** عنوان قسم مع أيقونة داخل مربع ملوّن */
    public LinearLayout sectionHeader(Context c, String icon, String title) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);

        ImageView box = new ImageView(c);
        box.setImageDrawable(icon(c, icon, onPrimary, 18));
        box.setScaleType(ImageView.ScaleType.FIT_CENTER);
        box.setBackground(gradient(c, 12, primary, primaryDark));
        box.setPadding(dp(c, 8), dp(c, 8), dp(c, 8), dp(c, 8));
        l.addView(box, new LinearLayout.LayoutParams(dp(c, 34), dp(c, 34)));

        TextView t = text(c, title, 15.5f, primary, true);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        tp.rightMargin = dp(c, 10);
        tp.leftMargin = dp(c, 4);
        l.addView(t, tp);

        View ln = new View(c);
        ln.setBackgroundColor(line);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(c, 1.4f), 1f);
        l.addView(ln, lp);
        return l;
    }

    // ---------- أيقونات مرسومة بالكود (بدون مكتبات) ----------

    public android.graphics.drawable.Drawable icon(Context c, String k, int color, int sizeDp) {
        int s = dp(c, sizeDp);
        Bitmap b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(color);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(1.8f, s * 0.075f));
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        glyph(cv, p, s, k);
        return new BitmapDrawable(c.getResources(), b);
    }

    private static float u(int s, double v) { return (float) (v * s / 24f); }

    private void glyph(Canvas cv, Paint p, int s, String k) {
        float uu = s / 24f;
        Paint fp = new Paint(p);
        fp.setStyle(Paint.Style.FILL);
        switch (k) {
            case "person": {
                cv.drawCircle(u(s, 12), u(s, 8), u(s, 4), p);
                cv.drawArc(new RectF(u(s, 4.5f), u(s, 13), u(s, 19.5f), u(s, 27)), 180, 180, false, p);
                break;
            }
            case "people": {
                cv.drawCircle(u(s, 9), u(s, 8), u(s, 3.5f), p);
                cv.drawArc(new RectF(u(s, 2.5f), u(s, 13.5f), u(s, 15.5f), u(s, 25)), 180, 180, false, p);
                cv.drawCircle(u(s, 17), u(s, 9.5f), u(s, 2.8f), p);
                cv.drawArc(new RectF(u(s, 13), u(s, 14.5f), u(s, 23), u(s, 23)), 190, 140, false, p);
                break;
            }
            case "id": {
                cv.drawRoundRect(new RectF(u(s, 2.5f), u(s, 5), u(s, 21.5f), u(s, 19)), u(s, 2.5f), u(s, 2.5f), p);
                cv.drawCircle(u(s, 8), u(s, 10.5f), u(s, 2.2f), p);
                cv.drawLine(u(s, 11.5f), u(s, 9.5f), u(s, 19), u(s, 9.5f), p);
                cv.drawLine(u(s, 11.5f), u(s, 13.5f), u(s, 17), u(s, 13.5f), p);
                cv.drawLine(u(s, 5), u(s, 15.5f), u(s, 11), u(s, 15.5f), p);
                break;
            }
            case "badge": star(cv, p, u(s, 12), u(s, 12.5f), u(s, 8.2f), u(s, 3.6f), 5);
                break;
            case "calendar": {
                cv.drawRoundRect(new RectF(u(s, 3.5f), u(s, 5.5f), u(s, 20.5f), u(s, 19.5)), u(s, 2.5f), u(s, 2.5f), p);
                cv.drawLine(u(s, 3.5f), u(s, 10), u(s, 20.5f), u(s, 10), p);
                cv.drawLine(u(s, 7.5f), u(s, 3.5f), u(s, 7.5f), u(s, 7), p);
                cv.drawLine(u(s, 16.5f), u(s, 3.5f), u(s, 16.5f), u(s, 7), p);
                cv.drawCircle(u(s, 9), u(s, 14.5), u(s, 1.1), fp);
                cv.drawCircle(u(s, 15), u(s, 14.5), u(s, 1.1), fp);
                break;
            }
            case "bank": {
                Path roof = new Path();
                roof.moveTo(u(s, 12), u(s, 3.5f));
                roof.lineTo(u(s, 21), u(s, 8.5f));
                roof.lineTo(u(s, 3), u(s, 8.5f));
                roof.close();
                cv.drawPath(roof, p);
                cv.drawLine(u(s, 6), u(s, 11.5f), u(s, 6), u(s, 17.5f), p);
                cv.drawLine(u(s, 12), u(s, 11.5f), u(s, 12), u(s, 17.5f), p);
                cv.drawLine(u(s, 18), u(s, 11.5f), u(s, 18), u(s, 17.5f), p);
                cv.drawLine(u(s, 3.5f), u(s, 20), u(s, 20.5f), u(s, 20), p);
                break;
            }
            case "money": {
                cv.drawCircle(u(s, 12), u(s, 12), u(s, 9), p);
                cv.drawCircle(u(s, 12), u(s, 12), u(s, 5), p);
                cv.drawCircle(u(s, 12), u(s, 12), u(s, 1.6f), fp);
                break;
            }
            case "home": {
                Path r = new Path();
                r.moveTo(u(s, 3.5f), u(s, 12));
                r.lineTo(u(s, 12), u(s, 4));
                r.lineTo(u(s, 20.5f), u(s, 12));
                cv.drawPath(r, p);
                cv.drawRoundRect(new RectF(u(s, 6), u(s, 11.5f), u(s, 18), u(s, 20)), u(s, 1.5f), u(s, 1.5f), p);
                break;
            }
            case "doc": {
                Path pg = new Path();
                pg.moveTo(u(s, 5.5f), u(s, 3.5f));
                pg.lineTo(u(s, 14), u(s, 3.5f));
                pg.lineTo(u(s, 19), u(s, 8.5f));
                pg.lineTo(u(s, 19), u(s, 20.5f));
                pg.lineTo(u(s, 5.5f), u(s, 20.5f));
                pg.close();
                cv.drawPath(pg, p);
                cv.drawLine(u(s, 14), u(s, 3.5f), u(s, 14), u(s, 8.5f), p);
                cv.drawLine(u(s, 8.5f), u(s, 12.5f), u(s, 15.5f), u(s, 12.5f), p);
                cv.drawLine(u(s, 8.5f), u(s, 16), u(s, 15.5f), u(s, 16), p);
                break;
            }
            case "star": star(cv, p, u(s, 12), u(s, 12.5f), u(s, 9), u(s, 4), 5);
                break;
            case "search": {
                cv.drawCircle(u(s, 10.5f), u(s, 10.5f), u(s, 6.5f), p);
                cv.drawLine(u(s, 15.5f), u(s, 15.5f), u(s, 20.5f), u(s, 20.5f), p);
                break;
            }
            case "list": {
                cv.drawLine(u(s, 9), u(s, 6), u(s, 20), u(s, 6), p);
                cv.drawLine(u(s, 9), u(s, 12), u(s, 20), u(s, 12), p);
                cv.drawLine(u(s, 9), u(s, 18), u(s, 20), u(s, 18), p);
                cv.drawCircle(u(s, 4.5f), u(s, 6), u(s, 1.4f), fp);
                cv.drawCircle(u(s, 4.5f), u(s, 12), u(s, 1.4f), fp);
                cv.drawCircle(u(s, 4.5f), u(s, 18), u(s, 1.4f), fp);
                break;
            }
            case "stats": {
                cv.drawLine(u(s, 3.5f), u(s, 20), u(s, 20.5f), u(s, 20), p);
                cv.drawLine(u(s, 6), u(s, 20), u(s, 6), u(s, 13), p);
                cv.drawLine(u(s, 12), u(s, 20), u(s, 12), u(s, 7), p);
                cv.drawLine(u(s, 18), u(s, 20), u(s, 18), u(s, 15), p);
                break;
            }
            case "tools": {
                cv.drawCircle(u(s, 12), u(s, 12), u(s, 8.5f), p);
                cv.drawCircle(u(s, 12), u(s, 12), u(s, 3.5f), p);
                for (int i = 0; i < 8; i++) {
                    double a = Math.PI / 4 * i;
                    cv.drawLine(u(s, 12) + (float) Math.cos(a) * u(s, 8.5f),
                            u(s, 12) + (float) Math.sin(a) * u(s, 8.5f),
                            u(s, 12) + (float) Math.cos(a) * u(s, 11.2f),
                            u(s, 12) + (float) Math.sin(a) * u(s, 11.2f), p);
                }
                break;
            }
            case "print": {
                cv.drawRoundRect(new RectF(u(s, 4), u(s, 8.5f), u(s, 20), u(s, 17)), u(s, 2), u(s, 2), p);
                cv.drawRect(new RectF(u(s, 7), u(s, 4), u(s, 17), u(s, 9)), p);
                cv.drawRect(new RectF(u(s, 7.5f), u(s, 13), u(s, 16.5f), u(s, 19.5f)), p);
                cv.drawCircle(u(s, 17), u(s, 11), u(s, 1), fp);
                break;
            }
            case "export": {
                cv.drawRoundRect(new RectF(u(s, 4), u(s, 11), u(s, 20), u(s, 20)), u(s, 2), u(s, 2), p);
                cv.drawLine(u(s, 12), u(s, 3.5f), u(s, 12), u(s, 13.5f), p);
                Path h = new Path();
                h.moveTo(u(s, 8.5f), u(s, 7));
                h.lineTo(u(s, 12), u(s, 3.5f));
                h.lineTo(u(s, 15.5f), u(s, 7));
                cv.drawPath(h, p);
                break;
            }
            case "import": {
                cv.drawRoundRect(new RectF(u(s, 4), u(s, 11), u(s, 20), u(s, 20)), u(s, 2), u(s, 2), p);
                cv.drawLine(u(s, 12), u(s, 3.5f), u(s, 12), u(s, 13.5f), p);
                Path h = new Path();
                h.moveTo(u(s, 8.5f), u(s, 10));
                h.lineTo(u(s, 12), u(s, 13.5f));
                h.lineTo(u(s, 15.5f), u(s, 10));
                cv.drawPath(h, p);
                break;
            }
            case "backup": {
                cv.drawOval(new RectF(u(s, 5), u(s, 4), u(s, 19), u(s, 9.5f)), p);
                cv.drawLine(u(s, 5), u(s, 6.75f), u(s, 5), u(s, 16.5f), p);
                cv.drawLine(u(s, 19), u(s, 6.75f), u(s, 19), u(s, 16.5f), p);
                cv.drawArc(new RectF(u(s, 5), u(s, 14), u(s, 19), u(s, 19.5)), 0, 180, false, p);
                cv.drawLine(u(s, 12), u(s, 9.5f), u(s, 12), u(s, 13.5f), p);
                break;
            }
            case "restore": {
                cv.drawOval(new RectF(u(s, 5), u(s, 12.5f), u(s, 19), u(s, 18)), p);
                cv.drawLine(u(s, 5), u(s, 7.5f), u(s, 5), u(s, 15.25f), p);
                cv.drawLine(u(s, 19), u(s, 7.5f), u(s, 19), u(s, 15.25f), p);
                cv.drawArc(new RectF(u(s, 5), u(s, 4.5f), u(s, 19), u(s, 10)), 0, 180, false, p);
                cv.drawLine(u(s, 12), u(s, 4.5f), u(s, 12), u(s, 9), p);
                Path h = new Path();
                h.moveTo(u(s, 9), u(s, 7));
                h.lineTo(u(s, 12), u(s, 10));
                h.lineTo(u(s, 15), u(s, 7));
                cv.drawPath(h, p);
                break;
            }
            case "info": {
                cv.drawCircle(u(s, 12), u(s, 12), u(s, 9), p);
                cv.drawCircle(u(s, 12), u(s, 7.8f), u(s, 1.4f), fp);
                cv.drawLine(u(s, 12), u(s, 11), u(s, 12), u(s, 17), p);
                break;
            }
            case "shield": {
                Path sh = new Path();
                sh.moveTo(u(s, 12), u(s, 3.5f));
                sh.lineTo(u(s, 20), u(s, 6.5f));
                sh.lineTo(u(s, 19), u(s, 14));
                sh.quadTo(u(s, 17), u(s, 19), u(s, 12), u(s, 21));
                sh.quadTo(u(s, 7), u(s, 19), u(s, 5), u(s, 14));
                sh.lineTo(u(s, 4), u(s, 6.5f));
                sh.close();
                cv.drawPath(sh, p);
                Path ch = new Path();
                ch.moveTo(u(s, 8.5f), u(s, 12));
                ch.lineTo(u(s, 11), u(s, 14.8f));
                ch.lineTo(u(s, 15.5f), u(s, 9.5f));
                cv.drawPath(ch, p);
                break;
            }
            case "update": {
                cv.drawArc(new RectF(u(s, 4.5f), u(s, 4.5f), u(s, 19.5f), u(s, 19.5f)), 30, 285, false, p);
                Path h = new Path();
                h.moveTo(u(s, 17.5f), u(s, 3.5f));
                h.lineTo(u(s, 18.5f), u(s, 8.5f));
                h.lineTo(u(s, 13.5f), u(s, 9.5f));
                cv.drawPath(h, p);
                break;
            }
            case "license": {
                Path pg = new Path();
                pg.moveTo(u(s, 5), u(s, 3.5f));
                pg.lineTo(u(s, 19), u(s, 3.5f));
                pg.lineTo(u(s, 19), u(s, 16.5f));
                pg.lineTo(u(s, 15), u(s, 16.5f));
                pg.lineTo(u(s, 15), u(s, 21.5f));
                pg.lineTo(u(s, 11.5f), u(s, 18.5f));
                pg.lineTo(u(s, 8), u(s, 21.5f));
                pg.lineTo(u(s, 8), u(s, 16.5f));
                pg.lineTo(u(s, 5), u(s, 16.5f));
                pg.close();
                cv.drawPath(pg, p);
                star(cv, p, u(s, 12), u(s, 9), u(s, 3), u(s, 1.3f), 5);
                break;
            }
            case "warning": {
                Path tr = new Path();
                tr.moveTo(u(s, 12), u(s, 3.5f));
                tr.lineTo(u(s, 21.5f), u(s, 20));
                tr.lineTo(u(s, 2.5f), u(s, 20));
                tr.close();
                cv.drawPath(tr, p);
                cv.drawLine(u(s, 12), u(s, 9.5f), u(s, 12), u(s, 14.5f), p);
                cv.drawCircle(u(s, 12), u(s, 17.2f), u(s, 1.3f), fp);
                break;
            }
            case "plus": {
                cv.drawLine(u(s, 12), u(s, 4), u(s, 12), u(s, 20), p);
                cv.drawLine(u(s, 4), u(s, 12), u(s, 20), u(s, 12), p);
                break;
            }
            case "edit": {
                Path pn = new Path();
                pn.moveTo(u(s, 4.5f), u(s, 19.5f));
                pn.lineTo(u(s, 5.5f), u(s, 15.5f));
                pn.lineTo(u(s, 16), u(s, 5));
                pn.quadTo(u(s, 17.5f), u(s, 3.5f), u(s, 19), u(s, 5));
                pn.quadTo(u(s, 20.5f), u(s, 6.5f), u(s, 19), u(s, 8));
                pn.lineTo(u(s, 8.5f), u(s, 18.5f));
                pn.close();
                cv.drawPath(pn, p);
                cv.drawLine(u(s, 14.6f), u(s, 6.4f), u(s, 17.6f), u(s, 9.4f), p);
                break;
            }
            case "trash": {
                cv.drawRoundRect(new RectF(u(s, 5), u(s, 7), u(s, 19), u(s, 20.5f)), u(s, 2), u(s, 2), p);
                cv.drawLine(u(s, 3), u(s, 7), u(s, 21), u(s, 7), p);
                cv.drawLine(u(s, 9), u(s, 4), u(s, 15), u(s, 4), p);
                cv.drawLine(u(s, 10), u(s, 11), u(s, 10), u(s, 16.5f), p);
                cv.drawLine(u(s, 14), u(s, 11), u(s, 14), u(s, 16.5f), p);
                break;
            }
            case "check": {
                Path ch = new Path();
                ch.moveTo(u(s, 4.5f), u(s, 12.5f));
                ch.lineTo(u(s, 10), u(s, 18));
                ch.lineTo(u(s, 19.5f), u(s, 6));
                cv.drawPath(ch, p);
                break;
            }
            case "lock": {
                cv.drawRoundRect(new RectF(u(s, 5.5f), u(s, 11), u(s, 18.5f), u(s, 20.5f)), u(s, 2.5f), u(s, 2.5f), p);
                cv.drawArc(new RectF(u(s, 8), u(s, 3.5f), u(s, 16), u(s, 13)), 180, 180, false, p);
                cv.drawCircle(u(s, 12), u(s, 15.5f), u(s, 1.5f), fp);
                break;
            }
            case "key": {
                cv.drawCircle(u(s, 8), u(s, 9.5f), u(s, 4), p);
                cv.drawLine(u(s, 11), u(s, 12.5f), u(s, 19.5f), u(s, 21), p);
                cv.drawLine(u(s, 16.5f), u(s, 18), u(s, 18.5f), u(s, 16), p);
                cv.drawLine(u(s, 18.5f), u(s, 20), u(s, 20.5f), u(s, 18), p);
                break;
            }
            case "building": {
                cv.drawRoundRect(new RectF(u(s, 5), u(s, 3.5f), u(s, 19), u(s, 20.5f)), u(s, 1.5f), u(s, 1.5f), p);
                cv.drawCircle(u(s, 9), u(s, 8), u(s, 1.1f), fp);
                cv.drawCircle(u(s, 15), u(s, 8), u(s, 1.1f), fp);
                cv.drawCircle(u(s, 9), u(s, 13), u(s, 1.1f), fp);
                cv.drawCircle(u(s, 15), u(s, 13), u(s, 1.1f), fp);
                cv.drawLine(u(s, 2.5f), u(s, 20.5f), u(s, 21.5f), u(s, 20.5f), p);
                break;
            }
            case "globe": {
                cv.drawCircle(u(s, 12), u(s, 12), u(s, 8.5f), p);
                cv.drawOval(new RectF(u(s, 8), u(s, 3.5f), u(s, 16), u(s, 20.5f)), p);
                cv.drawLine(u(s, 3.5f), u(s, 12), u(s, 20.5f), u(s, 12), p);
                break;
            }
            case "phone": {
                cv.drawRoundRect(new RectF(u(s, 7), u(s, 3), u(s, 17), u(s, 21)), u(s, 2.5f), u(s, 2.5f), p);
                cv.drawLine(u(s, 10), u(s, 18), u(s, 14), u(s, 18), p);
                break;
            }
            case "folder": {
                Path fo = new Path();
                fo.moveTo(u(s, 3), u(s, 19.5f));
                fo.lineTo(u(s, 3), u(s, 6));
                fo.lineTo(u(s, 9.5f), u(s, 6));
                fo.lineTo(u(s, 11.5f), u(s, 8.5f));
                fo.lineTo(u(s, 21), u(s, 8.5f));
                fo.lineTo(u(s, 21), u(s, 19.5f));
                fo.close();
                cv.drawPath(fo, p);
                break;
            }
            default: { // نقطة افتراضية
                cv.drawCircle(u(s, 12), u(s, 12), u(s, 5), fp);
            }
        }
    }

    private void star(Canvas cv, Paint p, float cx, float cy, float rOut, float rIn, int points) {
        Path st = new Path();
        for (int i = 0; i < points * 2; i++) {
            double a = Math.PI * i / points - Math.PI / 2;
            float r = (i % 2 == 0) ? rOut : rIn;
            float x = cx + (float) Math.cos(a) * r;
            float y = cy + (float) Math.sin(a) * r;
            if (i == 0) st.moveTo(x, y); else st.lineTo(x, y);
        }
        st.close();
        cv.drawPath(st, p);
    }

    // ---------- أزرار ----------

    public Button button(Context c, String s, boolean filled) {
        Button b = new Button(c);
        b.setText(s);
        b.setTextSize(15);
        b.setAllCaps(false);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        b.setTextColor(filled ? onPrimary : primary);
        b.setBackground(box(c, 16, filled ? primary : card, filled ? 0 : primary, 1.4f));
        b.setPadding(dp(c, 10), dp(c, 13), dp(c, 10), dp(c, 13));
        b.setElevation(dp(c, filled ? 3 : 1));
        return b;
    }

    /** زر رئيسي متدرج بأيقونة */
    public Button bigButton(Context c, String s, String icon, boolean filled) {
        Button b = button(c, s, filled);
        b.setTextSize(15.5f);
        if (filled) b.setBackground(gradient(c, 18, primary, primaryDark));
        b.setCompoundDrawablePadding(dp(c, 10));
        b.setCompoundDrawablesRelativeWithIntrinsicBounds(
                icon(c, icon, filled ? onPrimary : primary, 18), null, null, null);
        return b;
    }

    /** زر شبحي بأيقونة (مربع شبكي) */
    public LinearLayout tileButton(Context c, String s, String icon, Runnable onClick) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER);
        l.setBackground(box(c, 16, fieldBg, line, 1f));
        l.setPadding(dp(c, 6), dp(c, 12), dp(c, 6), dp(c, 12));
        ImageView iv = new ImageView(c);
        iv.setImageDrawable(icon(c, icon, primary, 22));
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        l.addView(iv, new LinearLayout.LayoutParams(dp(c, 26), dp(c, 26)));
        TextView t = text(c, s, 12.5f, text, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(c, 6), 0, 0);
        l.addView(t, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        l.setOnClickListener(v -> { if (onClick != null) onClick.run(); });
        l.setClickable(true);
        return l;
    }

    // ---------- حقول الإدخال ----------

    /** حقل إدخال مقيّد حسب النوع مع أيقونة وحدود تركيز */
    public EditText field(Context c, int kind, String hint) {
        return field(c, kind, hint, null);
    }

    public EditText field(Context c, int kind, String hint, String iconKind) {
        final EditText e = new EditText(c);
        e.setHint(hint);
        e.setHintTextColor(sub);
        e.setTextColor(text);
        e.setTextSize(15);
        e.setBackground(box(c, 14, fieldBg, line, 1.2f));
        int p = dp(c, 14);
        e.setPadding(p, p, p, p);
        if (iconKind != null) {
            e.setCompoundDrawablePadding(dp(c, 10));
            e.setCompoundDrawablesRelativeWithIntrinsicBounds(
                    icon(c, iconKind, sub, 19), null, null, null);
        }
        e.setOnFocusChangeListener((v, has) -> e.setBackground(
                box(c, 14, fieldBg, has ? primary : line, has ? 1.8f : 1.2f)));
        if (kind == Employee.K_NUM) {
            e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
            e.addTextChangedListener(new FilterWatcher(e, true));
        } else if (kind == Employee.K_TEXT) {
            e.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                    | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
            e.addTextChangedListener(new FilterWatcher(e, false));
        } else { // حر أو تاريخ
            e.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                    | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        }
        if (kind == Employee.K_DATE) attachDatePicker(c, e);
        return e;
    }

    /** قائمة منسدلة مع أيقونة على يمينها */
    public LinearLayout spinnerIconed(Context c, Spinner sp, String iconKind) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        ImageView iv = new ImageView(c);
        iv.setImageDrawable(icon(c, iconKind, sub, 19));
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(c, 22), dp(c, 22));
        ip.rightMargin = dp(c, 10);
        l.addView(iv, ip);
        l.addView(sp, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        return l;
    }

    /** حقل تاريخ: منتقي تقويم فقط (تاريخ فقط) — الضغط المطوّل يمسح */
    private static void attachDatePicker(final Context c, final EditText e) {
        e.setFocusable(false);
        e.setClickable(true);
        e.setCursorVisible(false);
        e.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                String iso = (String) e.getTag();
                if (iso != null) {
                    try {
                        cal.setTime(Employee.parseIso(iso));
                    } catch (Exception ignored) {}
                }
                DatePickerDialog dlg = new DatePickerDialog(c,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(android.widget.DatePicker dp, int y, int m, int day) {
                                Calendar cc = Calendar.getInstance();
                                cc.set(y, m, day);
                                SimpleDateFormat isoF = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
                                SimpleDateFormat dispF = new SimpleDateFormat("dd/MM/yyyy", Locale.US);
                                e.setTag(isoF.format(cc.getTime()));
                                e.setText(dispF.format(cc.getTime()));
                            }
                        },
                        cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH));
                dlg.show();
            }
        });
        e.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                e.setTag(null);
                e.setText("");
                return true;
            }
        });
    }

    /** مرشّح الإدخال الحي: أرقام فقط (مع تحويل الأرقام العربية) أو نص فقط */
    public static class FilterWatcher implements TextWatcher {
        private final EditText box;
        private final boolean digits;
        private boolean self = false;

        public FilterWatcher(EditText box, boolean digits) {
            this.box = box;
            this.digits = digits;
        }

        @Override
        public void beforeTextChanged(CharSequence s, int a, int b, int c) {}

        @Override
        public void onTextChanged(CharSequence s, int a, int b, int c) {}

        @Override
        public void afterTextChanged(Editable s) {
            if (self) return;
            String clean = digits ? Employee.digitsOnly(s.toString()) : Employee.textOnly(s.toString());
            if (!clean.equals(s.toString())) {
                self = true;
                s.replace(0, s.length(), clean);
                self = false;
            }
            try {
                box.setSelection(box.length());
            } catch (Exception ignored) {}
        }
    }

    public Spinner spinner(Context c, String[] items) {
        Spinner s = new Spinner(c);
        ArrayAdapter<String> ad = new ArrayAdapter<>(c, android.R.layout.simple_spinner_item, items);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(ad);
        s.setBackground(box(c, 14, fieldBg, line, 1.2f));
        int p = dp(c, 12);
        s.setPadding(p, p, p, p);
        return s;
    }

    /** شعار الإدارة: ملف مستورد من المستخدم إن وجد، وإلا الشعار المدمج */
    public static Bitmap loadLogo(Context c) {
        File f = new File(c.getFilesDir(), "logo.png");
        Bitmap b = null;
        if (f.exists()) b = BitmapFactory.decodeFile(f.getAbsolutePath());
        if (b == null) b = BitmapFactory.decodeResource(c.getResources(), R.drawable.logo);
        return b;
    }

    public static boolean customLogoExists(Context c) {
        return new File(c.getFilesDir(), "logo.png").exists();
    }
}
