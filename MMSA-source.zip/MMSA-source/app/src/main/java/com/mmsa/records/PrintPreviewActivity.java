package com.mmsa.records;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

/** معاينة كشف الطباعة A4 + الطباعة عبر نظام الأندرويد + حفظ/مشاركة PDF */
public class PrintPreviewActivity extends BaseActivity {

    private int id = -1;
    private File pdfFile;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        id = getIntent().getIntExtra("id", -1);

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(12), dp(12), dp(12), dp(12));

        TextView loading = th.text(this, "جارٍ تجهيز كشف الطباعة…", 14, th.sub, false);
        loading.setGravity(Gravity.CENTER);
        loading.setPadding(0, dp(24), 0, dp(8));
        ProgressBar pb = new ProgressBar(this);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(40), dp(40));
        pp.gravity = Gravity.CENTER_HORIZONTAL;
        body.addView(loading, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        body.addView(pb, pp);

        page("وضع الطباعة A4", body, null);
        prepare();
    }

    private void prepare() {
        new Thread(() -> {
            try {
                Employee e = Db.get(this).get(id);
                if (e == null) {
                    runOnUiThread(() -> {
                        toast("السجل غير موجود");
                        finish();
                    });
                    return;
                }
                pdfFile = PrintSheet.build(this, e);
                runOnUiThread(() -> showPreview(e));
            } catch (Exception ex) {
                runOnUiThread(() -> {
                    toast("تعذر تجهيز الكشف: " + ex.getMessage());
                    finish();
                });
            }
        }).start();
    }

    private void showPreview(Employee e) {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(12), dp(12), dp(12), dp(12));

        ScrollView sc = new ScrollView(this);
        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(4), dp(4), dp(4), dp(12));
        sc.addView(inner, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        body.addView(sc, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        TextView head = th.text(this, "معاينة كشف الطباعة — مقاس A4 للسجل: "
                + e.displayValue("fullName", false), 13, th.primary, true);
        head.setGravity(Gravity.CENTER);
        inner.addView(head, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        inner.setPadding(dp(4), dp(10), dp(4), dp(12));

        LinearLayout paper = new LinearLayout(this);
        paper.setOrientation(LinearLayout.VERTICAL);
        paper.setBackgroundColor(Color.WHITE);
        paper.setElevation(dp(6));
        int pw = Math.min(getWindowManager().getDefaultDisplay().getWidth() - dp(32), 720);
        try {
            ParcelFileDescriptor fd = ParcelFileDescriptor.open(pdfFile,
                    ParcelFileDescriptor.MODE_READ_ONLY);
            android.graphics.pdf.PdfRenderer renderer = new android.graphics.pdf.PdfRenderer(fd);
            android.graphics.pdf.PdfRenderer.Page page = renderer.openPage(0);
            float ratio = (float) page.getHeight() / page.getWidth();
            Bitmap bm = Bitmap.createBitmap(pw, Math.round(pw * ratio), Bitmap.Config.ARGB_8888);
            bm.eraseColor(0xFFFFFFFF);
            page.render(bm, null, null, android.graphics.pdf.PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
            page.close();
            renderer.close();
            fd.close();
            ImageView iv = new ImageView(this);
            iv.setImageBitmap(bm);
            iv.setAdjustViewBounds(true);
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            ip.topMargin = dp(8);
            inner.addView(iv, ip);
        } catch (Exception ex) {
            TextView err = th.text(this, "تعذر عرض المعاينة: " + ex.getMessage(), 13, th.danger, false);
            inner.addView(err);
        }

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.VERTICAL);
        bar.setBackgroundColor(th.card);
        bar.setElevation(dp(8));
        bar.setPadding(dp(12), dp(10), dp(12), dp(10));
        Button print = th.button(this, "طباعة عبر نظام الأندرويد", true);
        print.setOnClickListener(v -> doPrint());
        bar.addView(print, matchM(6));
        Button share = th.button(this, "حفظ PDF / مشاركة", false);
        share.setOnClickListener(v -> {
            MiniFileProvider.saveToDownloads(this, pdfFile, "application/pdf");
            MiniFileProvider.share(this, pdfFile, "كشف بيانات الموظف");
        });
        bar.addView(share, match());

        page("وضع الطباعة A4", body, bar);
    }

    /** الطباعة عبر PrintManager — اسم الورقة A4 */
    private void doPrint() {
        PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
        PrintAttributes attrs = new PrintAttributes.Builder()
                .setMediaSize(new PrintAttributes.MediaSize("ISO_A4", "android", 8270, 11690)
                        .asPortrait())
                .setColorMode(PrintAttributes.COLOR_MODE_COLOR)

                .build();
        pm.print("كشف_بيانات_الموظف", new PrintDocumentAdapter() {
            @Override
            public void onLayout(PrintAttributes oldA, PrintAttributes newA,
                                 CancellationSignal cs, LayoutResultCallback cb, Bundle extras) {
                if (cs != null && cs.isCanceled()) {
                    cb.onLayoutCancelled();
                    return;
                }
                PrintDocumentInfo info = new PrintDocumentInfo.Builder(pdfFile.getName())
                        .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                        .setPageCount(1)
                        .build();
                cb.onLayoutFinished(info, newA != oldA);
            }

            @Override
            public void onWrite(PageRange[] pages, ParcelFileDescriptor dest,
                                CancellationSignal cs, WriteResultCallback cb) {
                try {
                    FileInputStream in = new FileInputStream(pdfFile);
                    FileOutputStream out = new ParcelFileDescriptor.AutoCloseOutputStream(dest);
                    MiniFileProvider.copy(in, out);
                    cb.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});
                } catch (Exception ex) {
                    cb.onWriteFailed(ex.getMessage());
                }
            }
        }, attrs);
    }
}
