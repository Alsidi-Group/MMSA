package com.mmsa.records;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** مخزن المستخدمين وسجل الدخول: ملف «mmsa_users.json» داخل ملفات التطبيق —
 *  سطر JSON واحد لكل سجل (صالح للقراءة بأي أداة، مكتوب يدوياً بلا مكتبات):
 *  {"type":"user","email":...,"salt":...,"hash":...,"provider":...,"createdAt":...,"lastLogin":...}
 *  {"type":"log","at":...,"email":...,"action":...,"provider":...}
 *  يحفظ كل حسابات المستخدمين لمنع تكرار تسجيل نفس البريد، وسجل كامل لعمليات
 *  الدخول/الخروج/المحاولات الفاشلة (آخر 300 حدث). لا يخرج الملف من الهاتف
 *  إلا إذا صدّره المستخدم بنفسه من «الأدوات». */
public class AuthStore {

    /** حساب مستخدم مسجّل */
    public static class User {
        public String email;
        public String salt = "";
        public String hash = "";
        public String provider = "email";
        public String createdAt = "";
        public String lastLogin = "";
    }

    /** أنواع أحداث السجل */
    public static final String ACT_SIGNUP = "signup";
    public static final String ACT_LOGIN = "login";
    public static final String ACT_LOGIN_FAILED = "login_failed";
    public static final String ACT_GOOGLE = "google_link";
    public static final String ACT_LOGOUT = "logout";
    public static final String ACT_RESET = "reset";

    private static final int MAX_LOG = 300;

    private final File file;
    private final List<User> users = new ArrayList<>();
    private final List<String[]> log = new ArrayList<>(); // {التاريخ، البريد، العملية، الربط}

    public AuthStore(File dir) {
        file = new File(dir, "mmsa_users.json");
        load();
    }

    private void load() {
        users.clear();
        log.clear();
        try {
            if (!file.exists()) return;
            FileInputStream in = new FileInputStream(file);
            byte[] b = new byte[(int) file.length()];
            int n = 0, t;
            while (n < b.length && (t = in.read(b, n, b.length - n)) >= 0) n += t;
            in.close();
            for (String line : new String(b, 0, n, StandardCharsets.UTF_8).split("\n")) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String type = field(line, "type");
                if ("user".equals(type)) {
                    User u = new User();
                    u.email = field(line, "email");
                    u.salt = field(line, "salt");
                    u.hash = field(line, "hash");
                    u.provider = field(line, "provider");
                    u.createdAt = field(line, "createdAt");
                    u.lastLogin = field(line, "lastLogin");
                    if (!u.email.isEmpty()) users.add(u);
                } else if ("log".equals(type)) {
                    log.add(new String[]{field(line, "at"), field(line, "email"),
                            field(line, "action"), field(line, "provider")});
                }
            }
        } catch (Exception ignored) { // ملف تالف → يبدأ فارغاً
            users.clear();
            log.clear();
        }
    }

    private void save() {
        StringBuilder s = new StringBuilder();
        for (User u : users)
            s.append("{\"type\":\"user\",\"email\":").append(q(u.email))
                    .append(",\"salt\":").append(q(u.salt))
                    .append(",\"hash\":").append(q(u.hash))
                    .append(",\"provider\":").append(q(u.provider))
                    .append(",\"createdAt\":").append(q(u.createdAt))
                    .append(",\"lastLogin\":").append(q(u.lastLogin)).append("}\n");
        for (String[] e : log)
            s.append("{\"type\":\"log\",\"at\":").append(q(e[0]))
                    .append(",\"email\":").append(q(e[1]))
                    .append(",\"action\":").append(q(e[2]))
                    .append(",\"provider\":").append(q(e[3])).append("}\n");
        try {
            FileOutputStream out = new FileOutputStream(file);
            out.write(s.toString().getBytes(StandardCharsets.UTF_8));
            out.close();
        } catch (Exception ignored) {
        }
    }

    /** ملف التخزين داخل ملفات التطبيق */
    public File file() {
        return file;
    }

    public int userCount() {
        return users.size();
    }

    public int logCount() {
        return log.size();
    }

    /** البحث عن مستخدم بالبريد (غير حساس لحالة الأحرف والمسافات) */
    public User find(String email) {
        String e = norm(email);
        if (e.isEmpty()) return null;
        for (User u : users)
            if (norm(u.email).equals(e)) return u;
        return null;
    }

    /** إضافة مستخدم جديد — يعيد رسالة خطأ أو null عند النجاح.
     *  يرفض تكرار البريد نفسه: «لا يتم تكرار تسجيل نفس البيانات». */
    public String add(User u) {
        if (u.email == null || norm(u.email).isEmpty())
            return Lang.t("البريد الإلكتروني مطلوب", "Email is required",
                    "L'e-mail est requis", "Требуется эл. почта");
        if (find(u.email) != null)
            return Lang.t("هذا البريد مسجّل مسبقاً في ملف المستخدمين — سجّل الدخول به",
                    "This email is already registered — sign in with it",
                    "Cet e-mail est déjà enregistré — connectez-vous avec",
                    "Эта эл. почта уже зарегистрирована — войдите с ней");
        User nu = new User();
        nu.email = norm(u.email);
        nu.salt = u.salt == null ? "" : u.salt;
        nu.hash = u.hash == null ? "" : u.hash;
        nu.provider = u.provider == null || u.provider.isEmpty() ? "email" : u.provider;
        nu.createdAt = u.createdAt == null || u.createdAt.isEmpty() ? now() : u.createdAt;
        nu.lastLogin = u.lastLogin == null ? "" : u.lastLogin;
        users.add(nu);
        save();
        return null;
    }

    /** تحديث وقت آخر دخول */
    public void touch(String email) {
        User u = find(email);
        if (u != null) {
            u.lastLogin = now();
            save();
        }
    }

    /** تحديث نوع الربط (بريد/Google) مع الاحتفاظ بهاش كلمة السر إن وُجد */
    public void setProvider(String email, String provider) {
        User u = find(email);
        if (u != null) {
            u.provider = provider;
            save();
        }
    }

    /** حذف مستخدم (إعادة تعيين لمن نسى كلمة السر ليتمكن من إعادة التسجيل) */
    public boolean remove(String email) {
        String e = norm(email);
        if (e.isEmpty()) return false;
        for (int i = 0; i < users.size(); i++) {
            if (norm(users.get(i).email).equals(e)) {
                users.remove(i);
                save();
                return true;
            }
        }
        return false;
    }

    /** إضافة حدث إلى سجل الدخول (يحتفظ بآخر 300 حدث) */
    public void log(String email, String action, String provider) {
        log.add(new String[]{now(), norm(email), action, provider == null ? "" : provider});
        while (log.size() > MAX_LOG) log.remove(0);
        save();
    }

    /** نص السجل للعرض — الأحدث أولاً */
    public String logText() {
        if (log.isEmpty())
            return Lang.t("لا توجد سجلات دخول بعد", "No sign-in records yet",
                    "Aucun enregistrement de connexion", "Записей входа пока нет");
        StringBuilder s = new StringBuilder();
        for (int i = log.size() - 1; i >= 0; i--) {
            String[] e = log.get(i);
            s.append(e[0]).append("  —  ")
                    .append(actionLabel(e[2])).append("  —  ")
                    .append(e[1]).append("  (")
                    .append(providerLabel(e[3])).append(")\n");
        }
        return s.toString();
    }

    /** نص المستخدمين المسجلين للعرض */
    public String usersText() {
        if (users.isEmpty())
            return Lang.t("لا يوجد مستخدمون مسجلون بعد", "No registered users yet",
                    "Aucun utilisateur enregistré", "Нет зарегистрированных пользователей");
        StringBuilder s = new StringBuilder();
        for (User u : users)
            s.append("• ").append(u.email)
                    .append("  —  ").append(providerLabel(u.provider))
                    .append("  —  ").append(Lang.t("أول تسجيل: ", "First: ", "Premier : ", "Первый: "))
                    .append(u.createdAt).append("  —  ")
                    .append(Lang.t("آخر دخول: ", "Last sign-in: ", "Dernière connexion : ", "Последний вход: "))
                    .append(u.lastLogin).append('\n');
        return s.toString();
    }

    /** تسمية عربية/مترجمة لنوع الحدث */
    public static String actionLabel(String a) {
        switch (a) {
            case ACT_SIGNUP:
                return Lang.t("إنشاء حساب جديد", "Sign-up", "Inscription", "Регистрация");
            case ACT_LOGIN:
                return Lang.t("تسجيل دخول", "Sign-in", "Connexion", "Вход");
            case ACT_LOGIN_FAILED:
                return Lang.t("محاولة دخول فاشلة", "Failed sign-in", "Connexion échouée", "Неудачный вход");
            case ACT_GOOGLE:
                return Lang.t("ربط Gmail فوري", "Gmail instant link", "Liaison Gmail instantanée", "Мгновенная привязка Gmail");
            case ACT_LOGOUT:
                return Lang.t("تسجيل خروج", "Sign-out", "Déconnexion", "Выход");
            case ACT_RESET:
                return Lang.t("إعادة تعيين حساب", "Account reset", "Réinitialisation du compte", "Сброс аккаунта");
            default:
                return a;
        }
    }

    /** تسمية مترجمة لطريقة الربط */
    public static String providerLabel(String p) {
        return "google".equals(p)
                ? Lang.t("ربط Google", "Google link", "Liaison Google", "Привязка Google")
                : Lang.t("بريد وكلمة سر", "Email & password", "E-mail et mot de passe", "Почта и пароль");
    }

    /** قراءة قيمة حقل نصي من سطر JSON مكتوب يدوياً */
    private static String field(String line, String key) {
        int i = line.indexOf("\"" + key + "\":");
        if (i < 0) return "";
        i = line.indexOf('"', i + key.length() + 3); // علامة فتح قيمة النص
        if (i < 0) return "";
        StringBuilder s = new StringBuilder();
        for (int j = i + 1; j < line.length(); j++) {
            char ch = line.charAt(j);
            if (ch == '\\') {
                j++;
                if (j >= line.length()) break;
                char e = line.charAt(j);
                if (e == 'n') s.append('\n');
                else if (e == 't') s.append('\t');
                else if (e == 'r') s.append('\r');
                else if (e == 'u' && j + 4 < line.length()) { // هروب يونيكود رباعي
                    s.append((char) Integer.parseInt(line.substring(j + 1, j + 5), 16));
                    j += 4;
                } else s.append(e);
            } else if (ch == '"') break;
            else s.append(ch);
        }
        return s.toString();
    }

    /** ترميز نص JSON مع الهروب الكامل */
    private static String q(String v) {
        if (v == null) v = "";
        StringBuilder s = new StringBuilder("\"");
        for (int i = 0; i < v.length(); i++) {
            char c = v.charAt(i);
            if (c == '"' || c == '\\') s.append('\\').append(c);
            else if (c == '\n') s.append("\\n");
            else if (c == '\r') s.append("\\r");
            else if (c == '\t') s.append("\\t");
            else if (c < 32) s.append(String.format(Locale.US, "\\u%04x", (int) c));
            else s.append(c);
        }
        return s.append('"').toString();
    }

    private static String norm(String email) {
        return email == null ? "" : email.trim().toLowerCase(Locale.US);
    }

    static String now() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date());
    }
}
