package com.mmsa.records;

import android.accounts.AccountManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** صفحة الترحيب والدخول — ترتيب عمودي متسلسل نظيف بلا أي تراكب أو هوامش سالبة:
 *  أولاً لوحة ترحيبية متدرجة بارتفاع طبيعي حسب محتواها (الشعار + إدارة الخدمات
 *  الطبية العسكرية + منظومة بيانات)، ثم بطاقة زجاجية تحتها مباشرة بمسافة ثابتة
 *  لتسجيل الدخول أو إنشاء حساب جديد بالبريد الإلكتروني (Gmail) وكلمة السر، أو
 *  الربط الفوري بحساب Gmail المختار من الجهاز. الحسابات وسجل الدخول تُحفظ
 *  محلياً داخل الهاتف فقط (mmsa_users.json). */
public class LoginActivity extends BaseActivity {

    private boolean signupMode = false;
    private EditText fMail, fPwd;
    private TextView titleT, switchT, forgotT;
    private Button goBtn;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Auth.isAuthed(this)) { // جلسة سابقة نشطة → مباشرة إلى الشاشة الرئيسية
            enter();
            return;
        }
        setContentView(buildUi());
    }

    private View buildUi() {
        ScrollView sc = new ScrollView(this);
        sc.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(14);
        root.setPadding(pad, dp(12), pad, dp(18));

        // ===== 1) اللوحة الترحيبية: ارتفاع طبيعي حسب المحتوى — لا تراكب ولا فراغ متضخم =====
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setGravity(Gravity.CENTER);
        hero.setBackground(th.hero(this, 28, false));
        hero.setPadding(pad, dp(20), pad, dp(26));

        // دائرة زجاجية زخرفية أعلى اللوحة (مثل التصميم المرجعي)
        ImageView orb = new ImageView(this);
        GradientDrawable ob = new GradientDrawable();
        ob.setShape(GradientDrawable.OVAL);
        ob.setColor(0x40FFFFFF);
        orb.setBackground(ob);
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(dp(34), dp(34));
        op.gravity = Gravity.START; // يمين الشاشة في العربية (مثل التصميم المرجعي)
        op.setMargins(0, dp(2), 0, dp(12));
        hero.addView(orb, op);

        ImageView logo = new ImageView(this);
        Bitmap lg = Theme.loadLogo(this);
        logo.setImageBitmap(lg);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        GradientDrawable disc = new GradientDrawable();
        disc.setShape(GradientDrawable.OVAL);
        disc.setColor(0xFFFFFFFF);
        logo.setBackground(disc);
        int pp = dp(7);
        logo.setPadding(pp, pp, pp, pp);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(98), dp(98));
        lp.gravity = Gravity.CENTER_HORIZONTAL;
        hero.addView(logo, lp);

        TextView org = th.text(this,
                Lang.t("إدارة الخدمات الطبية العسكرية",
                        "Military Medical Services Administration",
                        "Administration des services médicaux militaires",
                        "Управление военно-медицинской службой"),
                18, th.onPrimary, true);
        org.setGravity(Gravity.CENTER);
        org.setPadding(0, dp(14), 0, dp(2));
        hero.addView(org, match());

        TextView sys = th.text(this,
                Lang.t("منظومة بيانات", "Data Management System",
                        "Système de gestion des données", "Система управления данными"),
                14, Theme.blend(th.onPrimary, th.primary, 0.25f), false);
        sys.setGravity(Gravity.CENTER);
        sys.setPadding(0, dp(3), 0, 0);
        hero.addView(sys, match());

        root.addView(hero, match()); // تسلسل طبيعي — بلا هامش سالب إطلاقاً

        // ===== 2) البطاقة الزجاجية تحتها مباشرة بمسافة ثابتة =====
        LinearLayout card = th.card(this, 24, 18);
        root.addView(card, matchM(14));

        titleT = th.text(this, "", 17, th.text, true);
        card.addView(titleT, matchM(4));

        switchT = th.text(this, "", 13, th.sub, false);
        switchT.setClickable(true);
        switchT.setOnClickListener(v -> toggleMode());
        card.addView(switchT, matchM(12));

        fMail = th.field(this, 99,
                Lang.t("البريد الإلكتروني (Gmail)", "Email address (Gmail)",
                        "Adresse e-mail (Gmail)", "Эл. почта (Gmail)"), "mail");
        fMail.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        card.addView(fMail, matchM(10));

        fPwd = th.field(this, 99,
                Lang.t("كلمة السر", "Password", "Mot de passe", "Пароль"), "lock");
        fPwd.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        card.addView(fPwd, matchM(4));

        forgotT = th.text(this,
                Lang.t("نسيت كلمة السر؟", "Forgot password?", "Mot de passe oublié ?", "Забыли пароль?"),
                12.5f, th.primary, true);
        forgotT.setGravity(Gravity.END);
        forgotT.setClickable(true);
        forgotT.setOnClickListener(v -> forgotPassword());
        card.addView(forgotT, matchM(14));

        goBtn = th.button(this, "", true);
        goBtn.setOnClickListener(v -> submit());
        card.addView(goBtn, matchM(12));

        TextView or = th.text(this, Lang.t("أو", "or", "ou", "или"), 12.5f, th.sub, true);
        or.setGravity(Gravity.CENTER);
        card.addView(or, matchM(10));

        // زر الربط الفوري بحساب Gmail: اختيار الحساب من الجهاز ثم دخول مباشر بلا كلمة سر
        LinearLayout gBtn = new LinearLayout(this);
        gBtn.setOrientation(LinearLayout.HORIZONTAL);
        gBtn.setGravity(Gravity.CENTER);
        gBtn.setBackground(th.box(this, 26, th.night ? 0xE6202937 : 0xE6FFFFFF, th.glassStroke, 1f));
        gBtn.setPadding(dp(14), dp(12), dp(14), dp(12));
        gBtn.setClickable(true);
        TextView gDisc = th.text(this, "G", 14, 0xFF1A73E8, true);
        gDisc.setGravity(Gravity.CENTER);
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.OVAL);
        gd.setColor(0xFFFFFFFF);
        gDisc.setBackground(gd);
        gBtn.addView(gDisc, new LinearLayout.LayoutParams(dp(26), dp(26)));
        TextView gT = th.text(this,
                Lang.t("المتابعة بحساب Google (Gmail)", "Continue with Google (Gmail)",
                        "Continuer avec Google (Gmail)", "Продолжить с Google (Gmail)"),
                14, th.night ? 0xFFE8E8E8 : 0xFF333333, true);
        LinearLayout.LayoutParams gtp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        gtp.setMarginStart(dp(10));
        gBtn.addView(gT, gtp);
        gBtn.setOnClickListener(v -> pickGoogle());
        card.addView(gBtn, matchM(6));

        // ملاحظة الخصوصية
        TextView note = th.text(this,
                Lang.t("دخولك يُحفظ في ملف محلي داخل الهاتف (mmsa_users.json) — لا تُرسل بياناتك إلى أي جهة",
                        "Your sign-in is kept in a local file on this phone (mmsa_users.json) — nothing is sent anywhere",
                        "Connexion stockée dans un fichier local (mmsa_users.json) — aucune donnée n'est envoyée",
                        "Вход хранится в локальном файле на телефоне (mmsa_users.json) — данные никуда не отправляются"),
                11, th.sub, false);
        note.setGravity(Gravity.CENTER);
        note.setPadding(0, dp(6), 0, 0);
        card.addView(note);

        sc.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        applyMode();
        return sc;
    }

    /** التبديل بين تسجيل الدخول وإنشاء حساب جديد */
    private void toggleMode() {
        signupMode = !signupMode;
        applyMode();
    }

    private void applyMode() {
        titleT.setText(signupMode
                ? Lang.t("إنشاء حساب جديد", "Create new account", "Créer un nouveau compte", "Создать новый аккаунт")
                : Lang.t("تسجيل الدخول", "Sign in", "Connexion", "Вход"));
        switchT.setText(signupMode
                ? Lang.t("لديك حساب؟ سجّل الدخول", "Have an account? Sign in", "Vous avez un compte ? Connexion", "Есть аккаунт? Войти")
                : Lang.t("مستخدم جديد؟ إنشاء حساب جديداً", "New user? Create an account", "Nouvel utilisateur ? Créer un compte", "Новый пользователь? Создать аккаунт"));
        switchT.setTextColor(signupMode ? th.primary : th.sub);
        forgotT.setVisibility(signupMode ? View.GONE : View.VISIBLE);
        goBtn.setText(signupMode
                ? Lang.t("إنشاء الحساب", "Create account", "Créer le compte", "Создать аккаунт")
                : Lang.t("متابعة", "Continue", "Continuer", "Продолжить"));
    }

    private void submit() {
        String mail = fMail.getText().toString().trim();
        String pwd = fPwd.getText().toString();
        String err = signupMode ? Auth.signup(this, mail, pwd) : Auth.login(this, mail, pwd);
        if (err != null) {
            dlg()
                    .setTitle(Lang.t("تعذّر الإكمال", "Cannot continue", "Impossible de continuer", "Не удалось продолжить"))
                    .setMessage(err)
                    .setPositiveButton(Lang.t("حسناً", "OK", "OK", "OK"), null)
                    .show();
            return;
        }
        enter();
    }

    /** من نسى كلمة السر: شرح + إعادة تعيين حساب البريد من ملف المستخدمين */
    private void forgotPassword() {
        dlg()
                .setTitle(Lang.t("نسيت كلمة السر", "Forgot password", "Mot de passe oublié", "Забыли пароль"))
                .setMessage(Lang.t(
                        "كلمة السر مشفرة داخل الهاتف ولا يمكن استعادتها. إعادة التعيين تحذف حساب هذا البريد من ملف المستخدمين (mmsa_users.json) لتتمكن من إنشاء حساب جديد بكلمة سر جديدة.",
                        "The password is encrypted on this phone and cannot be recovered. Resetting deletes this email's account from the users file (mmsa_users.json) so you can create a new one with a new password.",
                        "Le mot de passe est chiffré sur ce téléphone et ne peut être récupéré. La réinitialisation supprime ce compte du fichier des utilisateurs (mmsa_users.json) afin d'en créer un nouveau.",
                        "Пароль зашифрован на телефоне и не может быть восстановлен. Сброс удаляет аккаунт из файла пользователей (mmsa_users.json), чтобы вы создали новый."))
                .setPositiveButton(Lang.t("إعادة تعيين الحساب", "Reset account", "Réinitialiser le compte", "Сбросить аккаунт"),
                        (d, w) -> {
                            String err = Auth.resetAccount(this, fMail.getText().toString());
                            if (err != null) {
                                toast(err);
                                return;
                            }
                            signupMode = true;
                            applyMode();
                            fPwd.setText("");
                            toast(Lang.t("أُعيد تعيين الحساب — أنشئ حساباً جديداً بالبريد نفسه",
                                    "Account reset — create a new one with the same email",
                                    "Compte réinitialisé — créez-en un nouveau avec le même e-mail",
                                    "Аккаунт сброшен — создайте новый с той же эл. почтой"));
                        })
                .setNegativeButton(Lang.t("إلغاء", "Cancel", "Annuler", "Отмена"), null)
                .show();
    }

    /** الربط الفوري بحساب Gmail: نافذة اختيار الحسابات من الجهاز ثم دخول مباشر */
    private void pickGoogle() {
        try {
            Intent i = AccountManager.newChooseAccountIntent(null, null,
                    new String[]{"com.google"}, false, null, null, null, null);
            startActivityForResult(i, Auth.REQ_GOOGLE);
        } catch (Exception e) {
            dlg()
                    .setTitle(Lang.t("خدمة Google غير متوفرة", "Google service unavailable", "Service Google indisponible", "Сервис Google недоступен"))
                    .setMessage(Lang.t(
                            "تعذر الوصول إلى حسابات Google على هذا الجهاز — استخدم البريد الإلكتروني وكلمة السر.",
                            "Could not reach Google accounts on this device — use email and password instead.",
                            "Impossible d'accéder aux comptes Google — utilisez l'e-mail et le mot de passe.",
                            "Не удалось получить доступ к аккаунтам Google — используйте эл. почту и пароль."))
                    .setPositiveButton(Lang.t("حسناً", "OK", "OK", "OK"), null)
                    .show();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == Auth.REQ_GOOGLE && data != null) {
            String acc = data.getStringExtra(AccountManager.KEY_ACCOUNT_NAME);
            if (acc != null && !acc.isEmpty()) {
                Auth.googleLogin(this, acc);
                enter();
            }
        }
    }

    private void enter() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
