package com.mmsa.records;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;

/** نموذج الإدخال/التعديل: أقسام بعناوين وأيقونات + خانات مقيّدة + قوائم منسدلة */
public class FormActivity extends BaseActivity {

    private Spinner sType, sIdType, sRank;
    private EditText eNum, fNat, fName, fUnit, fJoin, fAppoint, fDecree, fProm, fDue,
            fGrade, fBank, fBranch, fAccount, fSalary;
    private int editId = -1;
    private boolean listenersOn = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        editId = getIntent().getIntExtra("id", -1);

        ScrollView sc = new ScrollView(this);
        sc.setFillViewport(true);
        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(16), dp(16), dp(16), dp(24));
        sc.addView(inner, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.addView(sc, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.VERTICAL);
        bar.setBackgroundColor(th.card);
        bar.setElevation(dp(10));
        bar.setPadding(dp(16), dp(12), dp(16), dp(12));
        Button save = th.bigButton(this,
                editId < 0 ? "حفظ في قاعدة البيانات" : "حفظ التعديلات", "check", true);
        save.setOnClickListener(v -> save());
        bar.addView(save, match());

        page(editId < 0 ? "إدخال بيانات موظف جديد" : "تعديل بيانات الموظف", body, bar);

        // ===== قسم الصفة ونوع الرقم =====
        LinearLayout c1 = th.card(this, 20, 16);
        inner.addView(c1, matchM(12));
        c1.addView(th.sectionHeader(this, "person", "الصفة ونوع الرقم"), matchM(10));
        c1.addView(th.label(this, "الصفة"), match());
        sType = th.spinner(this, new String[]{Employee.TYPE_MIL, Employee.TYPE_CIV});
        c1.addView(th.spinnerIconed(this, sType, "person"), matchM(8));
        c1.addView(th.label(this, "نوع الرقم"), match());
        sIdType = th.spinner(this, new String[]{Employee.ID_FIN, Employee.ID_MIL});
        c1.addView(th.spinnerIconed(this, sIdType, "badge"), matchM(8));
        c1.addView(th.label(this, "الرقم (أحد النوعين فقط)"), match());
        eNum = th.field(this, Employee.K_NUM, "أرقام فقط", "badge");
        c1.addView(eNum, match());

        // ===== قسم الرتبة =====
        LinearLayout c2 = th.card(this, 20, 16);
        inner.addView(c2, matchM(12));
        c2.addView(th.sectionHeader(this, "badge", "الرتبة"), matchM(10));
        c2.addView(th.label(this, "الرتبة — تتغير القائمة حسب الصفة"), match());
        sRank = th.spinner(this, Employee.RANKS_MIL);
        c2.addView(th.spinnerIconed(this, sRank, "star"), match());

        // ===== قسم البيانات الأساسية =====
        LinearLayout c3 = th.card(this, 20, 16);
        inner.addView(c3, matchM(12));
        c3.addView(th.sectionHeader(this, "doc", "البيانات الأساسية"), matchM(10));
        fNat = addField(c3, "الرقم الوطني (أرقام فقط)", Employee.K_NUM, "أرقام فقط", "id");
        fName = addField(c3, "الاسم الرباعي (نص فقط)", Employee.K_TEXT, "أربعة أسماء", "person");
        fUnit = addField(c3, "الجهة التابع لها (نص فقط)", Employee.K_TEXT, "مثال: المستشفى العسكري", "building");

        // ===== قسم المواعيد والقرارات =====
        LinearLayout c4 = th.card(this, 20, 16);
        inner.addView(c4, matchM(12));
        c4.addView(th.sectionHeader(this, "calendar", "المواعيد والقرارات"), matchM(10));
        fJoin = addField(c4, "تاريخ الالتحاق بالوحدة التابع لها الآن (تاريخ فقط)",
                Employee.K_DATE, "اضغط لاختيار التاريخ — ضغط مطوّل للمسح", "calendar");
        fAppoint = addField(c4, "تاريخ التعيين (تاريخ فقط)",
                Employee.K_DATE, "اضغط لاختيار التاريخ — ضغط مطوّل للمسح", "calendar");
        fDecree = addField(c4, "رقم قرار التعيين (أرقام فقط)", Employee.K_NUM, "أرقام فقط", "doc");
        fProm = addField(c4, "تاريخ آخر قرار ترقية (تاريخ فقط)",
                Employee.K_DATE, "اضغط لاختيار التاريخ — ضغط مطوّل للمسح", "calendar");
        fDue = addField(c4, "تاريخ الاستحقاق (تاريخ فقط)",
                Employee.K_DATE, "اضغط لاختيار التاريخ — ضغط مطوّل للمسح", "calendar");

        // ===== قسم الدرجة والبيانات المالية =====
        LinearLayout c5 = th.card(this, 20, 16);
        inner.addView(c5, matchM(12));
        c5.addView(th.sectionHeader(this, "money", "الدرجة والبيانات المالية"), matchM(10));
        fGrade = addField(c5, "الدرجة الحالية (أرقام أو نص)", Employee.K_FREE, "مثال: 8 أو أولى", "star");
        fBank = addField(c5, "اسم المصرف (نص فقط)", Employee.K_TEXT, "مثال: مصرف الجمهورية", "bank");
        fBranch = addField(c5, "فرع المصرف (نص فقط)", Employee.K_TEXT, "مثال: فرع طرابلس", "folder");
        fAccount = addField(c5, "رقم الحساب المصرفي (أرقام فقط)", Employee.K_NUM, "أرقام فقط", "money");
        fSalary = addField(c5, "قيمة المرتب الشهري (أرقام أو نص)", Employee.K_FREE, "مثال: 1200", "money");

        sType.setOnItemSelectedListener(typeSel);
        sIdType.setOnItemSelectedListener(idSel);

        if (editId >= 0) prefill();
        listenersOn = true;
    }

    private EditText addField(LinearLayout c, String label, int kind, String hint, String icon) {
        c.addView(th.label(this, label), match());
        EditText f = th.field(this, kind, hint, icon);
        c.addView(f, matchM(8));
        return f;
    }

    private final AdapterView.OnItemSelectedListener typeSel =
            new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> p, android.view.View v, int pos, long id) {
                    if (!listenersOn) return;
                    rebuildRanks(null);
                }

                @Override
                public void onNothingSelected(AdapterView<?> p) {}
            };

    private final AdapterView.OnItemSelectedListener idSel =
            new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> p, android.view.View v, int pos, long id) {
                    // لا تغيير إضافي — النوع يحدد عند الحفظ
                }

                @Override
                public void onNothingSelected(AdapterView<?> p) {}
            };

    /** بناء قائمة الرتب حسب الصفة مع الحفاظ على الاختيار الحالي إن وجد */
    private void rebuildRanks(String want) {
        boolean mil = sType.getSelectedItemPosition() == 0;
        String[] ranks = mil ? Employee.RANKS_MIL : Employee.RANKS_CIV;
        String current = want != null ? want
                : (sRank.getSelectedItem() != null ? sRank.getSelectedItem().toString() : null);
        android.widget.ArrayAdapter<String> ad = new android.widget.ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, ranks);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sRank.setAdapter(ad);
        if (current != null) {
            for (int i = 0; i < ranks.length; i++) {
                if (ranks[i].equals(current)) {
                    sRank.setSelection(i);
                    break;
                }
            }
        }
    }

    private void prefill() {
        Employee e = Db.get(this).get(editId);
        if (e == null) {
            toast("السجل غير موجود");
            finish();
            return;
        }
        sType.setSelection(e.val("empType").equals(Employee.TYPE_CIV) ? 1 : 0);
        rebuildRanks(e.val("rank"));
        if (!e.val("finNumber").isEmpty()) sIdType.setSelection(0);
        else if (!e.val("milNumber").isEmpty()) sIdType.setSelection(1);
        eNum.setText(e.val("finNumber").isEmpty() ? e.val("milNumber") : e.val("finNumber"));
        fNat.setText(e.val("nationalId"));
        fName.setText(e.val("fullName"));
        fUnit.setText(e.val("unit"));
        setDate(fJoin, e.val("joinDate"));
        setDate(fAppoint, e.val("appointDate"));
        fDecree.setText(e.val("appointDecree"));
        setDate(fProm, e.val("lastPromotion"));
        setDate(fDue, e.val("dueDate"));
        fGrade.setText(e.val("grade"));
        fBank.setText(e.val("bankName"));
        fBranch.setText(e.val("bankBranch"));
        fAccount.setText(e.val("bankAccount"));
        fSalary.setText(e.val("salary"));
    }

    private void setDate(EditText f, String iso) {
        if (iso == null || iso.isEmpty()) return;
        f.setTag(iso);
        f.setText(Employee.isoToDisp(iso));
    }

    private String num(EditText f) {
        return Employee.digitsOnly(f.getText().toString());
    }

    private String txt(EditText f) {
        return f.getText().toString().trim();
    }

    private void save() {
        Employee e = new Employee();
        e.id = editId;
        e.d.put("empType", sType.getSelectedItem().toString());
        boolean fin = sIdType.getSelectedItemPosition() == 0;
        String n = num(eNum);
        e.d.put("finNumber", fin ? n : "");
        e.d.put("milNumber", fin ? "" : n);
        e.d.put("rank", sRank.getSelectedItem() != null ? sRank.getSelectedItem().toString() : "");
        e.d.put("nationalId", num(fNat));
        e.d.put("fullName", txt(fName));
        e.d.put("unit", txt(fUnit));
        e.d.put("joinDate", fJoin.getTag() != null ? fJoin.getTag().toString() : "");
        e.d.put("appointDate", fAppoint.getTag() != null ? fAppoint.getTag().toString() : "");
        e.d.put("appointDecree", num(fDecree));
        e.d.put("lastPromotion", fProm.getTag() != null ? fProm.getTag().toString() : "");
        e.d.put("dueDate", fDue.getTag() != null ? fDue.getTag().toString() : "");
        e.d.put("grade", txt(fGrade));
        e.d.put("bankName", txt(fBank));
        e.d.put("bankBranch", txt(fBranch));
        e.d.put("bankAccount", num(fAccount));
        e.d.put("salary", txt(fSalary));

        String err = Db.get(this).validate(e);
        if (err != null) {
            new AlertDialog.Builder(this)
                    .setTitle("تعذّر الحفظ")
                    .setMessage(err)
                    .setPositiveButton("حسناً", null)
                    .show();
            return;
        }
        boolean ok = editId < 0 ? Db.get(this).insert(e) : Db.get(this).update(e);
        if (ok) {
            toast(editId < 0 ? "تم حفظ الموظف بنجاح" : "تم حفظ التعديلات بنجاح");
            finish();
        } else {
            new AlertDialog.Builder(this)
                    .setTitle("تعذّر الحفظ")
                    .setMessage("الرقم مكرر في قاعدة البيانات — مفاتيح عدم التكرار: الرقم الوطني أو المالي أو العسكري")
                    .setPositiveButton("حسناً", null)
                    .show();
        }
    }
}
