package com.mmsa.records;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/** عرض كل الموظفين مع تصفية، ووضع اختيار للطباعة A4 */
public class ListActivity extends BaseActivity {

    private ListView lv;
    private TextView countView;
    private EditText filter;
    private ArrayList<Employee> data = new ArrayList<>();
    private EmpAdapter ad;
    private boolean pick = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        pick = getIntent().getBooleanExtra("pick", false);

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(12);

        LinearLayout top = th.card(this, 20, 14);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tp.setMargins(pad, pad, pad, dp(8));
        body.addView(top, tp);
        countView = th.text(this, "", 14, th.primary, true);
        top.addView(countView, matchM(6));
        if (pick) {
            TextView hint = th.text(this, "اختر الموظف لعرض كشف الطباعة A4", 12.5f, th.sub, false);
            top.addView(hint, matchM(6));
        }
        LinearLayout frow = new LinearLayout(this);
        frow.setOrientation(LinearLayout.HORIZONTAL);
        filter = th.field(this, Employee.K_FREE, "تصفية: اسم أو رقم أو رتبة", "search");
        frow.addView(filter, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button go = th.bigButton(this, "تصفية", "search", true);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        gp.leftMargin = dp(8);
        frow.addView(go, gp);
        go.setOnClickListener(v -> load(filter.getText().toString().trim()));
        top.addView(frow, match());

        lv = new ListView(this);
        lv.setDivider(new GradientDrawable());
        lv.setDividerHeight(dp(6));
        lv.setPadding(pad, dp(4), pad, dp(12));
        lv.setClipToPadding(false);
        ad = new EmpAdapter();
        lv.setAdapter(ad);
        lv.setOnItemClickListener((parent, view, position, id) -> {
            Employee e = data.get(position);
            if (pick) {
                Intent i = new Intent(this, PrintPreviewActivity.class);
                i.putExtra("id", e.id);
                startActivity(i);
                finish();
            } else {
                Intent i = new Intent(this, DetailsActivity.class);
                i.putExtra("id", e.id);
                startActivity(i);
            }
        });
        body.addView(lv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        page(pick ? "اختيار موظف للطباعة" : "عرض الكل", body, null);
    }

    @Override
    protected void onResume() {
        super.onResume();
        load(filter != null && filter.getText() != null
                ? filter.getText().toString().trim() : "");
    }

    private void load(String q) {
        data = (q == null || q.isEmpty()) ? Db.get(this).all() : Db.get(this).searchAll(q);
        countView.setText(pick ? "الموظفون: " + data.size()
                : "كل الموظفين: " + data.size() + (q.isEmpty() ? "" : " — نتائج التصفية"));
        ad.notifyDataSetChanged();
        if (data.isEmpty()) {
            TextView t = new TextView(this);
            t.setText(q.isEmpty() ? "لا توجد سجلات بعد — أضف موظفاً من الشاشة الرئيسية"
                    : "لا توجد نتائج مطابقة للتصفية");
            t.setTextColor(th.sub);
            t.setTextSize(14);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(40), 0, 0);
            lv.setAdapter(new BaseAdapter() {
                @Override
                public int getCount() { return 0; }
                @Override
                public Object getItem(int i) { return null; }
                @Override
                public long getItemId(int i) { return 0; }
                @Override
                public View getView(int i, View v, ViewGroup p) { return t; }
            });
        } else {
            lv.setAdapter(ad);
            ad.notifyDataSetChanged();
        }
    }

    private class EmpAdapter extends BaseAdapter {
        @Override
        public int getCount() { return data.size(); }

        @Override
        public Object getItem(int i) { return data.get(i); }

        @Override
        public long getItemId(int i) { return data.get(i).id; }

        @Override
        public View getView(int i, View convertView, ViewGroup parent) {
            Employee e = data.get(i);
            LinearLayout row = th.card(ListActivity.this, 18, 12);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);

            ImageView av = new ImageView(ListActivity.this);
            av.setImageDrawable(th.icon(ListActivity.this, "person", th.onPrimary, 22));
            av.setScaleType(ImageView.ScaleType.FIT_CENTER);
            av.setBackground(th.gradient(ListActivity.this, 20, th.primary, th.primaryDark));
            av.setPadding(dp(9), dp(9), dp(9), dp(9));
            LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(dp(44), dp(44));
            ap.rightMargin = dp(10);
            row.addView(av, ap);

            LinearLayout tx = new LinearLayout(ListActivity.this);
            tx.setOrientation(LinearLayout.VERTICAL);
            TextView name = th.text(ListActivity.this,
                    e.displayValue("fullName", false), 15, th.text, true);
            tx.addView(name, matchM(2));
            String nums = "";
            if (!e.val("nationalId").isEmpty()) nums += "الوطني: " + e.val("nationalId");
            if (!e.val("finNumber").isEmpty())
                nums += (nums.isEmpty() ? "" : " • ") + "المالي: " + e.val("finNumber");
            if (!e.val("milNumber").isEmpty())
                nums += (nums.isEmpty() ? "" : " • ") + "العسكري: " + e.val("milNumber");
            TextView sub = th.text(ListActivity.this, nums.isEmpty() ? "—" : nums, 12, th.sub, false);
            tx.addView(sub, match());
            row.addView(tx, new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            TextView rank = th.chip(ListActivity.this, e.displayValue("rank", true),
                    th.fieldBg, th.primary);
            row.addView(rank, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            return row;
        }
    }
}
