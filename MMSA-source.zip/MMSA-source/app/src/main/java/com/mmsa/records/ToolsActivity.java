package com.mmsa.records;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** أدوات البيانات: تصدير Excel/CSV، استيراد، نسخ احتياطي واستعادة */
public class ToolsActivity extends BaseActivity {

    private static final int REQ_IMPORT = 41;
    private static final int REQ_BACKUP = 42;
    private static final int REQ_RESTORE = 43;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        ScrollView sc = new ScrollView(this);
        sc.setFillViewport(true);
        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(14), dp(14), dp(14), dp(24));
        sc.addView(inner, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.addView(sc, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // تصدير
        LinearLayout c1 = th.card(this, 20, 16);
        inner.addView(c1, matchM(12));
        c1.addView(th.sectionHeader(this, "export", "تصدير البيانات"), matchM(8));
        c1.addView(th.text(this,
                "تصدير جميع الموظفين إلى ملف Excel أو CSV بترتيب الشيت، وحفظه في مجلد التنزيلات Downloads/MMSA مع فتح خيارات المشاركة.",
                12.5f, th.sub, false), matchM(10));
        Button xlsx = th.bigButton(this, "تصدير Excel (XLSX)", "export", true);
        xlsx.setOnClickListener(v -> exportAll(true));
        c1.addView(xlsx, matchM(6));
        Button csv = th.bigButton(this, "تصدير CSV", "export", false);
        csv.setOnClickListener(v -> exportAll(false));
        c1.addView(csv, match());

        // استيراد
        LinearLayout c2 = th.card(this, 20, 16);
        inner.addView(c2, matchM(12));
        c2.addView(th.sectionHeader(this, "import", "استيراد من ملف"), matchM(8));
        c2.addView(th.text(this,
                "استيراد موظفين من ملف Excel (XLSX) أو CSV. يجب أن يكون الصف الأول عناوين الأعمدة القياسية (أفضل طريقة: صدّر من التطبيق ثم عدّل). يتم تجاهل السجلات المكررة تلقائياً حسب مفاتيح عدم التكرار.",
                12.5f, th.sub, false), matchM(10));
        Button imp = th.bigButton(this, "اختيار ملف واستيراد", "import", true);
        imp.setOnClickListener(v -> pickImport());
        c2.addView(imp, match());

        // النسخ الاحتياطي
        LinearLayout c3 = th.card(this, 20, 16);
        inner.addView(c3, matchM(12));
        c3.addView(th.sectionHeader(this, "backup", "النسخ الاحتياطي"), matchM(8));
        c3.addView(th.text(this,
                "نسخة كاملة من قاعدة البيانات (SQLite) داخل ذاكرة الهاتف — احفظها في مكان آمن ويمكن استعادتها على أي هاتف.",
                12.5f, th.sub, false), matchM(10));
        Button bak = th.bigButton(this, "إنشاء نسخة احتياطية", "backup", true);
        bak.setOnClickListener(v -> pickBackup());
        c3.addView(bak, matchM(6));
        Button res = th.bigButton(this, "استعادة نسخة احتياطية", "restore", false);
        res.setOnClickListener(v -> pickRestore());
        c3.addView(res, match());

        page("أدوات البيانات", body, null);
    }

    private String stamp() {
        return new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
                .format(new Date(System.currentTimeMillis()));
    }

    private void exportAll(boolean xlsx) {
        toast("جارٍ التصدير…");
        new Thread(() -> {
            try {
                List<String[]> rows = new ArrayList<>();
                for (Employee e : Db.get(this).all()) rows.add(e.exportRow());
                File dir = MiniFileProvider.exportsDir(this);
                if (xlsx) {
                    File f = new File(dir, "MMSA_employees_" + stamp() + ".xlsx");
                    SheetIO.writeXlsx(f, Employee.EXPORT_HEADERS, rows);
                    runOnUiThread(() -> MiniFileProvider.exportAndShare(this, f,
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"));
                } else {
                    File f = new File(dir, "MMSA_employees_" + stamp() + ".csv");
                    SheetIO.writeCsv(f, Employee.EXPORT_HEADERS, rows);
                    runOnUiThread(() -> MiniFileProvider.exportAndShare(this, f, "text/csv"));
                }
            } catch (Exception ex) {
                runOnUiThread(() -> toast("تعذر التصدير: " + ex.getMessage()));
            }
        }).start();
    }

    private void pickImport() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "application/vnd.ms-excel", "text/csv", "text/comma-separated-values",
                "text/plain", "application/octet-stream"});
        startActivityForResult(i, REQ_IMPORT);
    }

    private void pickBackup() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/octet-stream");
        i.putExtra(Intent.EXTRA_TITLE, "MMSA_backup_" + stamp() + ".db");
        startActivityForResult(i, REQ_BACKUP);
    }

    private void pickRestore() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_RESTORE);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (data == null || data.getData() == null || res != RESULT_OK) return;
        Uri uri = data.getData();
        if (req == REQ_IMPORT) doImport(uri);
        else if (req == REQ_BACKUP) doBackup(uri);
        else if (req == REQ_RESTORE) confirmRestore(uri);
    }

    private String fileName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri,
                new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) {}
        return "";
    }

    private void doImport(Uri uri) {
        toast("جارٍ قراءة الملف…");
        new Thread(() -> {
            try {
                String name = fileName(uri).toLowerCase();
                List<String[]> rows;
                try (java.io.InputStream in = getContentResolver().openInputStream(uri)) {
                    if (name.endsWith(".csv")) {
                        rows = SheetIO.readCsv(in);
                    } else {
                        try {
                            rows = SheetIO.readXlsx(in);
                        } catch (Exception x) {
                            try (java.io.InputStream in2 = getContentResolver().openInputStream(uri)) {
                                rows = SheetIO.readCsv(in2);
                            }
                        }
                    }
                }
                ArrayList<Employee> candidates = mapRows(rows);
                int added = 0, dup = 0, bad = 0;
                String errMsg = null;
                if (candidates == null) {
                    errMsg = "لم يتم التعرف على عناوين الأعمدة. تأكد أن الصف الأول يحتوي العناوين القياسية (صدّر من التطبيق ثم عدّل)";
                } else {
                    int[] r = Db.get(this).importRows(candidates);
                    added = r[0]; dup = r[1]; bad = r[2];
                }
                final String fErr = errMsg;
                final int fa = added, fd = dup, fb = bad;
                runOnUiThread(() -> {
                    if (fErr != null) {
                        new AlertDialog.Builder(this)
                                .setTitle("تعذر الاستيراد").setMessage(fErr)
                                .setPositiveButton("حسناً", null).show();
                    } else {
                        new AlertDialog.Builder(this)
                                .setTitle("نتيجة الاستيراد")
                                .setMessage("أُضيف: " + fa + " موظف\nتجاهُل (مكرر): " + fd
                                        + "\nأسطر غير صالحة: " + fb)
                                .setPositiveButton("حسناً", null).show();
                    }
                });
            } catch (Exception ex) {
                runOnUiThread(() -> toast("تعذر الاستيراد: " + ex.getMessage()));
            }
        }).start();
    }

    /** مطابقة عناوين الأعمدة بالعربية مع المفاتيح القياسية */
    private static String matchKey(String header) {
        if (header == null) return null;
        String h = header.trim().replaceAll("\\s+", " ");
        for (int i = 0; i < Employee.EXPORT_HEADERS.length; i++) {
            if (Employee.EXPORT_HEADERS[i].equals(h)) return Employee.EXPORT_KEYS[i];
        }
        if (h.contains("الوطني")) return "nationalId";
        if (h.contains("الرباعي") || h.equals("الاسم")) return "fullName";
        if (h.contains("المالي") || h.contains("الوظيفي")) return "finNumber";
        if (h.contains("الصفة") || h.contains("الفئة")) return "empType";
        if (h.equals("الرتبة") || h.contains("الرتبة")) return "rank";
        if (h.contains("العسكري")) return "milNumber";
        if (h.contains("الجهة")) return "unit";
        if (h.contains("الالتحاق") || h.contains("الاتحاق")) return "joinDate";
        if (h.equals("تاريخ التعيين")) return "appointDate";
        if (h.contains("قرار التعيين")) return "appointDecree";
        if (h.contains("ترقية")) return "lastPromotion";
        if (h.contains("الاستحقاق")) return "dueDate";
        if (h.contains("الدرجة")) return "grade";
        if (h.contains("اسم المصرف") || (h.contains("المصرف") && h.contains("اسم"))) return "bankName";
        if (h.contains("فرع المصرف") || (h.contains("المصرف") && h.contains("فرع"))) return "bankBranch";
        if (h.contains("الحساب")) return "bankAccount";
        if (h.contains("المرتب") || h.contains("الراتب")) return "salary";
        return null;
    }

    private ArrayList<Employee> mapRows(List<String[]> rows) {
        if (rows == null || rows.isEmpty()) return null;
        String[] header = rows.get(0);
        int matched = 0;
        int[] keyIdx = new int[header.length];
        for (int i = 0; i < header.length; i++) {
            String k = matchKey(header[i]);
            keyIdx[i] = k == null ? -1 : indexOfKey(k);
            if (keyIdx[i] >= 0 && !k.equals("id")) matched++;
        }
        if (matched < 3) return null;
        ArrayList<Employee> out = new ArrayList<>();
        for (int r = 1; r < rows.size(); r++) {
            String[] row = rows.get(r);
            if (row == null) continue;
            boolean anyVal = false;
            for (String cell : row) if (cell != null && !cell.trim().isEmpty()) { anyVal = true; break; }
            if (!anyVal) continue;
            Employee e = new Employee();
            e.id = -1;
            for (int i = 0; i < header.length && i < row.length; i++) {
                int k = keyIdx[i];
                if (k < 0) continue;
                String key = Employee.EXPORT_KEYS[k];
                if (key.equals("id")) continue;
                String v = row[i] == null ? "" : row[i].trim();
                if (key.equals("empType") && v.isEmpty()) {
                    continue;
                }
                if (key.endsWith("Date")) {
                    v = Employee.anyToIso(v);
                    if (v.isEmpty()) continue;
                }
                e.d.put(key, v);
            }
            if (e.val("empType").isEmpty())
                e.d.put("empType", e.val("milNumber").isEmpty()
                        ? Employee.TYPE_CIV : Employee.TYPE_MIL);
            out.add(e);
        }
        return out;
    }

    private static int indexOfKey(String key) {
        for (int i = 0; i < Employee.EXPORT_KEYS.length; i++)
            if (Employee.EXPORT_KEYS[i].equals(key)) return i;
        return -1;
    }

    private void doBackup(Uri uri) {
        android.os.ParcelFileDescriptor pfd = null;
        try {
            Db.get(this).checkpoint();
            pfd = getContentResolver().openFileDescriptor(uri, "w");
            try (FileInputStream in = new FileInputStream(Db.get(this).dbPath())) {
                try (FileOutputStream out = new FileOutputStream(pfd.getFileDescriptor())) {
                    MiniFileProvider.copy(in, out);
                }
            }
            toast("تم إنشاء النسخة الاحتياطية بنجاح");
        } catch (Exception ex) {
            toast("تعذر الحفظ: " + ex.getMessage());
        } finally {
            if (pfd != null) {
                try { pfd.close(); } catch (Exception ignored) {}
            }
        }
    }

    private void confirmRestore(Uri uri) {
        confirm("استعادة نسخة احتياطية",
                "سيتم استبدال جميع البيانات الحالية بمحتوى النسخة المختارة. هل تريد المتابعة؟",
                () -> {
                    try {
                        File dbf = new File(Db.get(this).dbPath());
                        Db.reset(); // إغلاق القاعدة قبل الاستبدال
                        byte[] buf = new byte[8192];
                        try (java.io.InputStream in = getContentResolver().openInputStream(uri);
                             FileOutputStream out = new FileOutputStream(dbf)) {
                            int n;
                            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                        }
                        new File(dbf.getAbsolutePath() + "-wal").delete();
                        new File(dbf.getAbsolutePath() + "-shm").delete();
                        toast("تمت الاستعادة — إعادة تشغيل التطبيق");
                        Intent i = new Intent(this, MainActivity.class);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(i);
                        finishAffinity();
                    } catch (Exception ex) {
                        toast("تعذرت الاستعادة: " + ex.getMessage());
                    }
                });
    }
}
