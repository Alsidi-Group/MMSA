package com.mmsa.records;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * إدارة البيانات: تصدير واستيراد Excel / SQL / CSV من وإلى الهاتف + النسخ الاحتياطي.
 * الاستيراد يقبل أي ملف من الأنواع الثلاثة ويجاهل المكرر، والقيم غير الموجودة تبقى فارغة.
 */
public class ToolsActivity extends BaseActivity {

    private static final int REQ_IMPORT = 41;
    private static final int REQ_BACKUP = 42;
    private static final int REQ_RESTORE = 43;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        ScrollView sc = new ScrollView(this);
        sc.setFillViewport(true);
        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(14), dp(14), dp(14), dp(24));
        sc.addView(inner, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.addView(sc, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // ===== التصدير إلى الهاتف =====
        LinearLayout c1 = th.card(this, 20, 16);
        inner.addView(c1, matchM(12));
        c1.addView(th.sectionHeader(this, "export",
                Lang.t("تصدير البيانات إلى الهاتف", "Export to phone",
                        "Exportation vers le téléphone", "Экспорт на телефон")), matchM(8));
        c1.addView(th.text(this,
                Lang.t("تصدير جميع الموظفين إلى ملف Excel أو SQL أو CSV بترتيب الشيت، وحفظه في مجلد التنزيلات Downloads/MMSA مع فتح خيارات المشاركة.",
                        "Export all employees to Excel, SQL or CSV and save to Downloads/MMSA with sharing options.",
                        "Exportez tous les employés vers Excel, SQL ou CSV et enregistrez dans Downloads/MMSA.",
                        "Экспортируйте всех сотрудников в Excel, SQL или CSV и сохраните в Downloads/MMSA."),
                12.5f, th.sub, false), matchM(10));
        LinearLayout exRow = new LinearLayout(this);
        Button xlsx = th.bigButton(this, "Excel", "export", true);
        Button sql = th.bigButton(this, "SQL", "export", false);
        Button csv = th.bigButton(this, "CSV", "export", false);
        exRow.addView(xlsx, half());
        exRow.addView(sql, half());
        exRow.addView(csv, half());
        xlsx.setOnClickListener(v -> exportAll("xlsx"));
        sql.setOnClickListener(v -> exportAll("sql"));
        csv.setOnClickListener(v -> exportAll("csv"));
        c1.addView(exRow, match());

        // ===== الاستيراد من الهاتف =====
        LinearLayout c2 = th.card(this, 20, 16);
        inner.addView(c2, matchM(12));
        c2.addView(th.sectionHeader(this, "import",
                Lang.t("استيراد من الهاتف", "Import from phone",
                        "Importation du téléphone", "Импорт с телефона")), matchM(8));
        c2.addView(th.text(this,
                Lang.t("استيراد الموظفين من ملف Excel أو SQL أو CSV حسب البيانات الموجودة به وإضافتها إلى قاعدة بيانات التطبيق — الباقي من القيم الفارغة يبقى فارغاً كما هو. يجب أن يكون الصف الأول عناوين الأعمدة القياسية (أفضل طريقة: صدّر من التطبيق ثم عدّل)، وملف SQL يقبل عبارات INSERT. يتم تجاهل السجلات المكررة تلقائياً.",
                        "Import employees from an Excel, SQL or CSV file into the app database — missing values stay empty. The first row must be standard column headers (best: export from the app then edit); SQL files accept INSERT statements. Duplicates are skipped automatically.",
                        "Importez des employés depuis un fichier Excel, SQL ou CSV — les valeurs manquantes restent vides. La première ligne doit contenir les en-têtes standard ; les fichiers SQL acceptent les instructions INSERT. Les doublons sont ignorés.",
                        "Импорт сотрудников из файла Excel, SQL или CSV в базу данных — отсутствующие значения остаются пустыми. Первая строка — стандартные заголовки; SQL-файлы принимают INSERT. Дубликаты пропускаются."),
                12.5f, th.sub, false), matchM(10));
        Button imp = th.bigButton(this,
                Lang.t("اختيار ملف واستيراد (Excel / SQL / CSV)",
                        "Pick a file and import (Excel / SQL / CSV)",
                        "Choisir un fichier et importer (Excel / SQL / CSV)",
                        "Выбрать файл и импортировать (Excel / SQL / CSV)"),
                "import", true);
        imp.setOnClickListener(v -> pickImport());
        c2.addView(imp, match());

        // ===== النسخ الاحتياطي =====
        LinearLayout c3 = th.card(this, 20, 16);
        inner.addView(c3, matchM(12));
        c3.addView(th.sectionHeader(this, "backup",
                Lang.t("النسخ الاحتياطي", "Backup", "Sauvegarde", "Резервная копия")), matchM(8));
        c3.addView(th.text(this,
                Lang.t("نسخة كاملة من قاعدة البيانات (SQLite) داخل ذاكرة الهاتف — احفظها في مكان آمن ويمكن استعادتها على أي هاتف.",
                        "A full database backup (SQLite) — save it somewhere safe and restore it on any phone.",
                        "Une sauvegarde complète de la base (SQLite) — conservez-la en lieu sûr.",
                        "Полная резервная копия базы (SQLite) — сохраните в надёжном месте."),
                12.5f, th.sub, false), matchM(10));
        Button bak = th.bigButton(this,
                Lang.t("إنشاء نسخة احتياطية", "Create backup", "Créer une sauvegarde", "Создать копию"),
                "backup", true);
        bak.setOnClickListener(v -> pickBackup());
        c3.addView(bak, matchM(6));
        Button res = th.bigButton(this,
                Lang.t("استعادة نسخة احتياطية", "Restore backup", "Restaurer", "Восстановить"),
                "restore", false);
        res.setOnClickListener(v -> pickRestore());
        c3.addView(res, match());

        page(Lang.t("إدارة البيانات", "Data management", "Gestion des données", "Управление данными"),
                body, null);
    }

    private String stamp() {
        return new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
                .format(new Date(System.currentTimeMillis()));
    }

    /** تصدير بالصيغة المطلوبة: xlsx / sql / csv */
    private void exportAll(String kind) {
        toast(Lang.t("جارٍ التصدير…", "Exporting…", "Exportation…", "Экспорт…"));
        new Thread(() -> {
            try {
                List<Employee> all = Db.get(this).all();
                List<String[]> rows = new ArrayList<>();
                for (Employee e : all) rows.add(e.exportRow());
                File dir = MiniFileProvider.exportsDir(this);
                File f;
                String mime;
                if (kind.equals("xlsx")) {
                    f = new File(dir, "MMSA_employees_" + stamp() + ".xlsx");
                    SheetIO.writeXlsx(f, Employee.EXPORT_HEADERS, rows);
                    mime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                } else if (kind.equals("sql")) {
                    f = new File(dir, "MMSA_employees_" + stamp() + ".sql");
                    SqlIO.writeSql(f, all);
                    mime = "application/sql";
                } else {
                    f = new File(dir, "MMSA_employees_" + stamp() + ".csv");
                    SheetIO.writeCsv(f, Employee.EXPORT_HEADERS, rows);
                    mime = "text/csv";
                }
                File ff = f;
                String mm = mime;
                runOnUiThread(() -> MiniFileProvider.exportAndShare(this, ff, mm));
            } catch (Exception ex) {
                runOnUiThread(() -> toast(Lang.t("تعذر التصدير: ", "Export failed: ",
                        "Échec de l'export : ", "Ошибка экспорта: ") + ex.getMessage()));
            }
        }).start();
    }

    private void pickImport() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "application/vnd.ms-excel", "text/csv", "text/comma-separated-values",
                "application/sql", "text/plain", "application/octet-stream"});
        startActivityForResult(i, REQ_IMPORT);
    }

    private void pickBackup() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/octet-stream");
        i.putExtra(Intent.EXTRA_TITLE, "MMSA_backup_" + stamp() + ".db");
        startActivityForResult(i, REQ_BACKUP);
    }

    private void pickRestore() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_RESTORE);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (data == null || data.getData() == null || res != RESULT_OK) return;
        Uri uri = data.getData();
        if (req == REQ_IMPORT) doImport(uri);
        else if (req == REQ_BACKUP) doBackup(uri);
        else if (req == REQ_RESTORE) confirmRestore(uri);
    }

    private String fileName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri,
                new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) {}
        return "";
    }

    private void doImport(Uri uri) {
        toast(Lang.t("جارٍ قراءة الملف…", "Reading file…", "Lecture du fichier…", "Чтение файла…"));
        new Thread(() -> {
            try {
                String name = fileName(uri).toLowerCase();
                List<String[]> rows;
                boolean fromSql = false;
                try (java.io.InputStream in = getContentResolver().openInputStream(uri)) {
                    if (name.endsWith(".sql")) {
                        // ملف SQL: تحليل عبارات INSERT وإخراجها بترتيب أعمدة الشيت
                        SqlIO.SqlRows sq = SqlIO.readSql(in);
                        rows = sq.rows;
                        fromSql = true;
                        if (rows.isEmpty()) {
                            final String msg = sq.foundColumns
                                    ? Lang.t("لم يُعثر على صفوف صالحة داخل ملف SQL — تأكد من عبارات INSERT.",
                                            "No valid rows found in the SQL file — check the INSERT statements.",
                                            "Aucune ligne valide dans le fichier SQL — vérifiez les instructions INSERT.",
                                            "В SQL-файле нет допустимых строк — проверьте INSERT.")
                                    : Lang.t("لم يُعثر على عبارات INSERT داخل ملف SQL.",
                                            "No INSERT statements found in the SQL file.",
                                            "Aucune instruction INSERT dans le fichier SQL.",
                                            "В SQL-файле нет INSERT-выражений.");
                            runOnUiThread(() -> Theme.dialog(this)
                                    .setTitle(Lang.t("تعذر الاستيراد", "Import failed",
                                            "Échec de l'import", "Ошибка импорта"))
                                    .setMessage(msg)
                                    .setPositiveButton(Lang.t("حسناً", "OK", "OK", "OK"), null)
                                    .show());
                            return;
                        }
                    } else if (name.endsWith(".csv")) {
                        rows = SheetIO.readCsv(in);
                    } else {
                        try {
                            rows = SheetIO.readXlsx(in);
                        } catch (Exception x) {
                            try (java.io.InputStream in2 = getContentResolver().openInputStream(uri)) {
                                rows = SheetIO.readCsv(in2);
                            } catch (Exception x2) {
                                try (java.io.InputStream in3 = getContentResolver().openInputStream(uri)) {
                                    SqlIO.SqlRows sq = SqlIO.readSql(in3);
                                    rows = sq.rows;
                                    fromSql = true;
                                }
                            }
                        }
                    }
                }
                ArrayList<Employee> candidates = fromSql ? mapSqlRows(rows) : mapRows(rows);
                int added = 0, dup = 0, bad = 0;
                String errMsg = null;
                if (candidates == null) {
                    errMsg = Lang.t("لم يتم التعرف على عناوين الأعمدة. تأكد أن الصف الأول يحتوي العناوين القياسية (صدّر من التطبيق ثم عدّل)",
                            "Column headers not recognized. The first row must contain the standard headers (export from the app then edit).",
                            "En-têtes non reconnus. La première ligne doit contenir les en-têtes standard (exportez puis modifiez).",
                            "Заголовки не распознаны. Первая строка должна содержать стандартные заголовки (экспортируйте, затем редактируйте).");
                } else {
                    int[] r = Db.get(this).importRows(candidates);
                    added = r[0]; dup = r[1]; bad = r[2];
                }
                final String fErr = errMsg;
                final int fa = added, fd = dup, fb = bad;
                runOnUiThread(() -> {
                    if (fErr != null) {
                        Theme.dialog(this)
                                .setTitle(Lang.t("تعذر الاستيراد", "Import failed",
                                        "Échec de l'import", "Ошибка импорта"))
                                .setMessage(fErr)
                                .setPositiveButton(Lang.t("حسناً", "OK", "OK", "OK"), null)
                                .show();
                    } else {
                        Theme.dialog(this)
                                .setTitle(Lang.t("نتيجة الاستيراد", "Import result",
                                        "Résultat de l'import", "Результат импорта"))
                                .setMessage(Lang.t("أُضيف", "Added", "Ajoutés", "Добавлено") + ": " + fa + "\n"
                                        + Lang.t("تجاهُل (مكرر)", "Skipped (duplicates)", "Ignorés (doublons)", "Пропущено (дубликаты)") + ": " + fd
                                        + "\n" + Lang.t("أسطر غير صالحة", "Invalid rows", "Lignes invalides", "Недопустимые строки") + ": " + fb)
                                .setPositiveButton(Lang.t("حسناً", "OK", "OK", "OK"), null)
                                .show();
                    }
                });
            } catch (Exception ex) {
                runOnUiThread(() -> toast(Lang.t("تعذر الاستيراد: ", "Import failed: ",
                        "Échec de l'import : ", "Ошибка импорта: ") + ex.getMessage()));
            }
        }).start();
    }

    /** مطابقة عناوين الأعمدة بالعربية مع المفاتيح القياسية */
    private static String matchKey(String header) {
        if (header == null) return null;
        String h = header.trim().replaceAll("\\s+", " ");
        for (int i = 0; i < Employee.EXPORT_HEADERS.length; i++) {
            if (Employee.EXPORT_HEADERS[i].equals(h)) return Employee.EXPORT_KEYS[i];
        }
        // مطابقة إنجليزية/فرنسية/روسية لطيفة عند الاستيراد من نسخ مترجمة
        String low = h.toLowerCase();
        if (low.contains("national")) return "nationalId";
        if (low.contains("full name") || low.contains("nom complet")) return "fullName";
        if (low.contains("financial") || low.contains("financier") || low.contains("рабочий")) return "finNumber";
        if (low.contains("military") || low.contains("militaire") || low.contains("военный")) return "milNumber";
        if (low.contains("category") || low.contains("catégorie")) return "empType";
        if (low.contains("rank") || low.contains("grade ") || low.contains("звание")) return "rank";
        if (low.contains("entity") || low.contains("affectation") || low.contains("подраздел")) return "unit";
        if (low.contains("joining") || low.contains("присоедин")) return "joinDate";
        if (low.contains("appointment date") || low.contains("nomination")) return "appointDate";
        if (low.contains("decree") || low.contains("décret") || low.contains("приказ")) return "appointDecree";
        if (low.contains("promotion")) return "lastPromotion";
        if (low.contains("due") || low.contains("échéance")) return "dueDate";
        if (low.contains("current grade") || low.contains("ступень")) return "grade";
        if (low.contains("bank name") || low.contains("banque") || low.contains("банк")) return "bankName";
        if (low.contains("branch") || low.contains("agence") || low.contains("отделение")) return "bankBranch";
        if (low.contains("account") || low.contains("compte") || low.contains("счёт") || low.contains("счет")) return "bankAccount";
        if (low.contains("salary") || low.contains("salaire") || low.contains("зарплат")) return "salary";
        if (low.contains("qualification") || low.contains("académique") || low.contains("учёная") || low.contains("ученая"))
            return "qualification";
        if (low.contains("technical") || low.contains("technique") || low.contains("техническая"))
            return "techQual";
        if (low.contains("specialty") || low.contains("spécialité") || low.contains("специальность"))
            return "specialty";
        if (low.contains("increment") || low.contains("avancement") || low.contains("надбав"))
            return "annualAllowance";

        if (h.contains("الوطني")) return "nationalId";
        if (h.contains("الرباعي") || h.equals("الاسم")) return "fullName";
        if (h.contains("المالي") || h.contains("الوظيفي")) return "finNumber";
        if (h.contains("الصفة") || h.contains("الفئة")) return "empType";
        if (h.equals("الرتبة") || h.contains("الرتبة")) return "rank";
        if (h.contains("العسكري")) return "milNumber";
        if (h.contains("الجهة")) return "unit";
        if (h.contains("الالتحاق") || h.contains("الاتحاق")) return "joinDate";
        if (h.equals("تاريخ التعيين")) return "appointDate";
        if (h.contains("قرار التعيين")) return "appointDecree";
        if (h.contains("ترقية")) return "lastPromotion";
        if (h.contains("الاستحقاق")) return "dueDate";
        if (h.contains("الدرجة")) return "grade";
        if (h.contains("اسم المصرف") || (h.contains("المصرف") && h.contains("اسم"))) return "bankName";
        if (h.contains("فرع المصرف") || (h.contains("المصرف") && h.contains("فرع"))) return "bankBranch";
        if (h.contains("الحساب")) return "bankAccount";
        if (h.contains("المرتب") || h.contains("الراتب")) return "salary";
        if (h.contains("العلمي") || h.contains("المؤهل")) return "qualification";
        if (h.contains("الفني")) return "techQual";
        if (h.contains("التخصص")) return "specialty";
        if (h.contains("العلاو")) return "annualAllowance";
        return null;
    }

    /** تطبيع القيم حسب نوع العمود: أرقام فقط للأرقام، وتاريخ ISO للتواريخ */
    private static String normalize(String key, String v) {
        if (v == null) return "";
        v = v.trim();
        if (v.isEmpty()) return "";
        if (key.equals("finNumber") || key.equals("milNumber") || key.equals("nationalId")
                || key.equals("bankAccount")) {
            return Employee.digitsOnly(v);
        }
        if (key.endsWith("Date")) {
            return Employee.anyToIso(v);
        }
        return v;
    }

    /** صفوف Excel/CSV → موظفون (قيم فارغة تبقى فارغة) */
    private ArrayList<Employee> mapRows(List<String[]> rows) {
        if (rows == null || rows.isEmpty()) return null;
        String[] header = rows.get(0);
        int matched = 0;
        int[] keyIdx = new int[header.length];
        for (int i = 0; i < header.length; i++) {
            String k = matchKey(header[i]);
            keyIdx[i] = k == null ? -1 : indexOfKey(k);
            if (keyIdx[i] >= 0 && !k.equals("id")) matched++;
        }
        if (matched < 3) return null;
        ArrayList<Employee> out = new ArrayList<>();
        for (int r = 1; r < rows.size(); r++) {
            String[] row = rows.get(r);
            if (row == null) continue;
            boolean anyVal = false;
            for (String cell : row) if (cell != null && !cell.trim().isEmpty()) { anyVal = true; break; }
            if (!anyVal) continue;
            Employee e = new Employee();
            e.id = -1;
            for (int i = 0; i < header.length && i < row.length; i++) {
                int k = keyIdx[i];
                if (k < 0) continue;
                String key = Employee.EXPORT_KEYS[k];
                if (key.equals("id")) continue;
                String v = normalize(key, row[i] == null ? "" : row[i]);
                if (v.isEmpty()) continue; // القيمة الفارغة تبقى فارغة
                e.d.put(key, v);
            }
            if (e.val("empType").isEmpty())
                e.d.put("empType", e.val("milNumber").isEmpty()
                        ? Employee.TYPE_CIV : Employee.TYPE_MIL);
            out.add(e);
        }
        return out;
    }

    /** صفوف SQL (بترتيب أعمدة الشيت) → موظفون */
    private ArrayList<Employee> mapSqlRows(List<String[]> rows) {
        if (rows == null || rows.isEmpty()) return null;
        ArrayList<Employee> out = new ArrayList<>();
        for (String[] row : rows) {
            if (row == null) continue;
            boolean anyVal = false;
            for (String cell : row) if (cell != null && !cell.trim().isEmpty()) { anyVal = true; break; }
            if (!anyVal) continue;
            Employee e = new Employee();
            e.id = -1;
            for (int i = 0; i < Employee.EXPORT_KEYS.length && i < row.length; i++) {
                String key = Employee.EXPORT_KEYS[i];
                if (key.equals("id")) continue;
                String v = normalize(key, row[i]);
                if (v.isEmpty()) continue;
                e.d.put(key, v);
            }
            if (e.val("empType").isEmpty())
                e.d.put("empType", e.val("milNumber").isEmpty()
                        ? Employee.TYPE_CIV : Employee.TYPE_MIL);
            out.add(e);
        }
        return out;
    }

    private static int indexOfKey(String key) {
        for (int i = 0; i < Employee.EXPORT_KEYS.length; i++)
            if (Employee.EXPORT_KEYS[i].equals(key)) return i;
        return -1;
    }

    private void doBackup(Uri uri) {
        android.os.ParcelFileDescriptor pfd = null;
        try {
            Db.get(this).checkpoint();
            pfd = getContentResolver().openFileDescriptor(uri, "w");
            try (FileInputStream in = new FileInputStream(Db.get(this).dbPath())) {
                try (FileOutputStream out = new FileOutputStream(pfd.getFileDescriptor())) {
                    MiniFileProvider.copy(in, out);
                }
            }
            toast(Lang.t("تم إنشاء النسخة الاحتياطية بنجاح", "Backup created successfully",
                    "Sauvegarde créée avec succès", "Резервная копия создана"));
        } catch (Exception ex) {
            toast(Lang.t("تعذر الحفظ: ", "Save failed: ", "Échec de l'enregistrement : ",
                    "Ошибка сохранения: ") + ex.getMessage());
        } finally {
            if (pfd != null) {
                try { pfd.close(); } catch (Exception ignored) {}
            }
        }
    }

    private void confirmRestore(Uri uri) {
        confirm(Lang.t("استعادة نسخة احتياطية", "Restore backup", "Restaurer la sauvegarde", "Восстановить копию"),
                Lang.t("سيتم استبدال جميع البيانات الحالية بمحتوى النسخة المختارة. هل تريد المتابعة؟",
                        "All current data will be replaced by the selected backup. Continue?",
                        "Toutes les données actuelles seront remplacées. Continuer ?",
                        "Все текущие данные будут заменены выбранной копией. Продолжить?"),
                () -> {
                    try {
                        File dbf = new File(Db.get(this).dbPath());
                        Db.reset(); // إغلاق القاعدة قبل الاستبدال
                        byte[] buf = new byte[8192];
                        try (java.io.InputStream in = getContentResolver().openInputStream(uri);
                             FileOutputStream out = new FileOutputStream(dbf)) {
                            int n;
                            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                        }
                        new File(dbf.getAbsolutePath() + "-wal").delete();
                        new File(dbf.getAbsolutePath() + "-shm").delete();
                        toast(Lang.t("تمت الاستعادة — إعادة تشغيل التطبيق",
                                "Restored — restarting the app",
                                "Restauré — redémarrage de l'application",
                                "Восстановлено — перезапуск приложения"));
                        Intent i = new Intent(this, MainActivity.class);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(i);
                        finishAffinity();
                    } catch (Exception ex) {
                        toast(Lang.t("تعذرت الاستعادة: ", "Restore failed: ",
                                "Échec de la restauration : ", "Ошибка восстановления: ") + ex.getMessage());
                    }
                });
    }
}
