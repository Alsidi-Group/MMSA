package com.mmsa.records;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;

/** حول التطبيق: الشعار ثم الاسم والمطوّر والدولة والتفاصيل والإصدار + التحديثات + الترخيص المشفر */
public class AboutActivity extends BaseActivity {

    private static final int REQ_LOGO = 51;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        build();
        // فحص تلقائي صامت عند فتح الشاشة أيضاً (يعمل فقط عند توفر الإنترنت)
        Updater.autoCheck(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (th == null) th = Theme.of(this);
    }

    private void build() {
        ScrollView sc = new ScrollView(this);
        sc.setFillViewport(true);
        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(14), dp(14), dp(14), dp(24));
        sc.addView(inner, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.addView(sc, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // ===== بطاقة التعريف: الشعار ثم الاسم والمطوّر والدولة والتفاصيل والإصدار =====
        LinearLayout hero = th.card(this, 24, 22);
        inner.addView(hero, matchM(12));

        ImageView logo = new ImageView(this);
        logo.setImageBitmap(Theme.loadLogo(this));
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(104), dp(104));
        lp.gravity = Gravity.CENTER_HORIZONTAL;
        lp.topMargin = dp(4);
        hero.addView(logo, lp);

        TextView name = th.text(this, "منظومة البيانات", 21, th.primary, true);
        name.setGravity(Gravity.CENTER);
        hero.addView(name, matchM(3));

        TextView dev = th.text(this, "المطوّر: مروان السيدي — Marwan Alsidi", 14, th.text, true);
        dev.setGravity(Gravity.CENTER);
        hero.addView(dev, matchM(2));

        TextView country = th.text(this, "دولة ليبيا \uD83C\uDDF1\uD83C\uDDFE", 14, th.sub, false);
        country.setGravity(Gravity.CENTER);
        hero.addView(country, matchM(6));

        TextView det = th.text(this,
                "منظومة البيانات للكادر الوظيفي لإدارة الخدمات الطبية العسكرية",
                13.5f, th.sub, false);
        det.setGravity(Gravity.CENTER);
        det.setLineSpacing(dp(3), 1.1f);
        hero.addView(det, matchM(8));

        TextView ver = th.text(this, "الإصدار " + Updater.VERSION_NAME
                + " (" + Updater.VERSION_CODE + ")", 12.5f, th.sub, false);
        ver.setGravity(Gravity.CENTER);
        hero.addView(ver, matchM(0));

        // بوابة خفية (غير مذكورة في أي واجهة): ضغط مطوّل على رقم الإصدار
        ver.setOnLongClickListener(v -> {
            License.secretGate(this);
            return true;
        });

        // ===== التحديثات: خانة البحث عن التحديثات =====
        LinearLayout cu = th.card(this, 20, 16);
        inner.addView(cu, matchM(12));
        cu.addView(th.sectionHeader(this, "update", "التحديثات"), matchM(8));
        cu.addView(th.text(this,
                "يبحث التطبيق تلقائياً عن الإصدارات الجديدة عند توفر الاتصال بالإنترنت، "
                        + "وعند وجود إصدار أحدث تظهر نافذة تعرض ما الجديد فيه. يمكنك أيضاً الفحص يدوياً.",
                12.5f, th.sub, false), matchM(10));
        Button upd = th.bigButton(this, "البحث عن تحديثات", "update", true);
        upd.setOnClickListener(v -> Updater.check(this));
        cu.addView(upd, match());

        // ===== المظهر: 4 ثيمات =====
        LinearLayout ct = th.card(this, 20, 16);
        inner.addView(ct, matchM(12));
        ct.addView(th.sectionHeader(this, "star", "المظهر (4 ثيمات)"), matchM(8));
        RadioGroup rg = new RadioGroup(this);
        int cur = Theme.index(this);
        for (int i = 0; i < Theme.THEME_NAMES.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setText(Theme.THEME_NAMES[i]);
            rb.setTextSize(14);
            rb.setTextColor(th.text);
            rb.setId(100 + i);
            rb.setChecked(i == cur);
            rg.addView(rb);
        }
        rg.setOnCheckedChangeListener((group, checkedId) -> {
            Theme.save(this, checkedId - 100);
            th = Theme.of(this); // تطبيق فوري للألوان الجديدة
            getWindow().setStatusBarColor(th.primaryDark);
            getWindow().setNavigationBarColor(th.primaryDark);
            toast("تم تطبيق المظهر: " + Theme.THEME_NAMES[checkedId - 100]);
            build();
        });
        ct.addView(rg, match());

        // ===== شعار الإدارة =====
        LinearLayout cl = th.card(this, 20, 16);
        inner.addView(cl, matchM(12));
        cl.addView(th.sectionHeader(this, "shield", "شعار الإدارة"), matchM(8));
        cl.addView(th.text(this,
                Theme.customLogoExists(this)
                        ? "الشعار الحالي: مستورد من الهاتف."
                        : "الشعار المدمج هو الشعار الرسمي لإدارة الخدمات الطبية العسكرية. "
                        + "يمكنك استيراد شعار آخر من صورة على الهاتف وسيعمل فوراً في الواجهات وصفحة الطباعة.",
                12.5f, th.sub, false), matchM(10));
        Button imp = th.bigButton(this, "استيراد الشعار من الهاتف", "import", true);
        imp.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("image/*");
            startActivityForResult(Intent.createChooser(i, "اختر صورة الشعار"), REQ_LOGO);
        });
        cl.addView(imp, matchM(6));
        if (Theme.customLogoExists(this)) {
            Button rst = th.button(this, "إعادة الشعار الافتراضي", false);
            rst.setOnClickListener(v -> {
                new File(getFilesDir(), "logo.png").delete();
                toast("أُعيد الشعار الافتراضي");
                build();
            });
            cl.addView(rst, match());
        }

        // ===== الترخيص المشفر وخاص =====
        LinearLayout lic = th.card(this, 20, 16);
        inner.addView(lic, matchM(12));
        lic.addView(th.sectionHeader(this, "license", "الترخيص"), matchM(8));
        LinearLayout licRow = new LinearLayout(this);
        licRow.setOrientation(LinearLayout.HORIZONTAL);
        licRow.setGravity(Gravity.CENTER_VERTICAL);
        licRow.setBackground(th.box(this, 14, th.fieldBg, th.line, 1.2f));
        licRow.setPadding(dp(12), dp(12), dp(12), dp(12));
        licRow.setClickable(true);
        licRow.setOnClickListener(v -> License.show(this));
        ImageView licIv = new ImageView(this);
        licIv.setImageDrawable(th.icon(this, "license", th.onPrimary, 18));
        licIv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        licIv.setBackground(th.gradient(this, 12, th.primary, th.primaryDark));
        licIv.setPadding(dp(8), dp(8), dp(8), dp(8));
        licRow.addView(licIv, new LinearLayout.LayoutParams(dp(36), dp(36)));
        LinearLayout licTx = new LinearLayout(this);
        licTx.setOrientation(LinearLayout.VERTICAL);
        TextView licT = th.text(this, "عرض الترخيص المشفر", 14, th.primary, true);
        TextView licS = th.text(this, "ترخيص خاص وليس مفتوح المصدر — تحت رعاية وتطوير مروان السيدي",
                11.5f, th.sub, false);
        licTx.addView(licT);
        licTx.addView(licS);
        LinearLayout.LayoutParams ltp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        ltp.rightMargin = dp(10);
        ltp.leftMargin = dp(4);
        licRow.addView(licTx, ltp);
        ImageView chev = new ImageView(this);
        chev.setImageDrawable(th.icon(this, "key", th.sub, 16));
        licRow.addView(chev, new LinearLayout.LayoutParams(dp(20), dp(20)));
        lic.addView(licRow, match());

        // ===== تحذير السرية أسفل الواجهة =====
        LinearLayout warn = new LinearLayout(this);
        warn.setOrientation(LinearLayout.HORIZONTAL);
        warn.setGravity(Gravity.CENTER);
        warn.setBackground(th.box(this, 16, th.danger, 0, 0));
        warn.setPadding(dp(14), dp(12), dp(14), dp(12));
        TextView wt = th.text(this, "هذا التطبيق سري للغاية — عدم مشاركته مع الآخرين ⚠️",
                13.5f, th.onPrimary, true);
        wt.setGravity(Gravity.CENTER);
        warn.addView(wt);
        inner.addView(warn, match());

        page("حول التطبيق", body, null);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_LOGO || res != RESULT_OK || data == null || data.getData() == null) return;
        try {
            // قراءة بأبعاد معاينة أولاً لتقليل استهلاك الذاكرة ثم تصغير إلى 512 بكسل
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            try (java.io.InputStream probe = getContentResolver().openInputStream(data.getData())) {
                BitmapFactory.decodeStream(probe, null, bounds);
            }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
                toast("تعذر قراءة الصورة");
                return;
            }
            int sample = 1;
            while (Math.max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 512) sample *= 2;
            BitmapFactory.Options opt = new BitmapFactory.Options();
            opt.inSampleSize = sample;
            Bitmap b;
            try (java.io.InputStream in = getContentResolver().openInputStream(data.getData())) {
                b = BitmapFactory.decodeStream(in, null, opt);
            }
            if (b == null) {
                toast("تعذر قراءة الصورة");
                return;
            }
            if (b.getWidth() > 512 || b.getHeight() > 512) {
                int w = b.getWidth() > b.getHeight() ? 512 : Math.round(512f * b.getWidth() / b.getHeight());
                int h = b.getHeight() >= b.getWidth() ? 512 : Math.round(512f * b.getHeight() / b.getWidth());
                b = Bitmap.createScaledBitmap(b, w, h, true);
            }
            FileOutputStream fo = openFileOutput("logo.png", MODE_PRIVATE);
            b.compress(Bitmap.CompressFormat.PNG, 100, fo);
            fo.close();
            toast("تم استيراد الشعار — سيظهر في كل الواجهات وصفحة الطباعة");
            build();
        } catch (Exception ex) {
            toast("تعذر استيراد الشعار: " + ex.getMessage());
        }
    }
}
