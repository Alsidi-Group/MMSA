package com.mmsa.records;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.text.InputType;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/**
 * نظام الترخيص المشفر: يقرأ assets/license.dat (AES-256-GCM) ويحلله داخل التطبيق فقط.
 * الثوابت أدناه مخزّنة موهّاة بـ XOR — لا يوجد أي نص سري صريح في الكود أو داخل APK.
 */
public class License {

    private static final byte[] LIC_MASK = {-80, -64, 1, -37, -24, 45, 0, -88, -1, -67, -11, -29, 100, 12, 36, 73};
    private static final byte[] LIC_KEY = {27, -16, -20, 13, 43, -17, 124, 46, -115, 92, 33, 120, -49, 56, -85, -97, 81, 89, -47, 1, -104, -29, 80, 57, -87, 36, -115, 29, -62, 20, -82, 89};
    private static final byte[] SRC_ENC = {-15, -84, 114, -78, -116, 68, 95, -17, -115, -46, -128, -109, 85, 60, 28, 126, -119, -9};
    private static final byte[] PIN_ENC = {-127, -16, 48, -21, -39, 20, 57, -100};

    /** فك التمويه: XOR مع القناع */
    private static byte[] deobf(byte[] enc, int len) {
        byte[] out = new byte[len];
        for (int i = 0; i < len; i++) out[i] = (byte) (enc[i] ^ LIC_MASK[i % LIC_MASK.length]);
        return out;
    }

    /** نص الترخيص بعد فك التشفير من الملف المشفر */
    public static String text(Context c) {
        try (InputStream in = c.getAssets().open("license.dat")) {
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
            byte[] d = b.toByteArray();
            if (d.length < 24 || !(new String(d, 0, 5, "UTF-8")).equals("MLIC1"))
                throw new Exception("تنسيق غير صالح");
            javax.crypto.SecretKey ks = new javax.crypto.spec.SecretKeySpec(
                    deobf(LIC_KEY, LIC_KEY.length), "AES");
            javax.crypto.Cipher ci = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding");
            ci.init(javax.crypto.Cipher.DECRYPT_MODE, ks,
                    new javax.crypto.spec.GCMParameterSpec(128, d, 5, 12));
            byte[] plain = ci.doFinal(d, 17, d.length - 17);
            return new String(plain, "UTF-8");
        } catch (Exception e) {
            // احتياطي فقط في حال تلف الملف — بلا أي معلومات حساسة
            return "الترخيص مشفر وخاص — تحت رعاية وتطوير مروان السيدي — Marwan Alsidi.\n"
                    + "لا يحق لأحد تعديل المشروع أو إعادة توزيعه إلا بمالك مفتاح المصدر الرسمي.\n"
                    + "جميع الحقوق محفوظة © 2026";
        }
    }

    /** نافذة الترخيص المنبثقة (مشفّرة وخاص) */
    public static void show(Activity act) {
        Theme th = Theme.of(act);
        TextView tv = new TextView(act);
        tv.setText(text(act));
        tv.setTextSize(14);
        tv.setTextColor(th.text);
        tv.setLineSpacing(dp(act, 4), 1.15f);
        int p = dp(act, 20);
        tv.setPadding(p, p, p, p);

        ScrollView sc = new ScrollView(act);
        sc.addView(tv);
        Theme.dialog(act)
                .setTitle(Lang.t("الترخيص — مشفر وخاص", "License — encrypted & private",
                        "Licence — chiffrée et privée", "Лицензия — зашифрованная и частная"))
                .setView(sc)
                .setPositiveButton(Lang.t("إغلاق", "Close", "Fermer", "Закрыть"), null)
                .show();
    }

    /** مقارنة الرقم السري بمقارنة زمنية ثابتة (بدون تسريب التوقيت) */
    public static boolean checkPin(String s) {
        byte[] want = deobf(PIN_ENC, PIN_ENC.length);
        byte[] got = (s == null ? "" : s.trim()).getBytes(StandardCharsets.UTF_8);
        boolean ok = want.length == got.length;
        int m = Math.min(want.length, got.length);
        for (int i = 0; i < m; i++) ok &= want[i] == got[i];
        for (int i = m; i < want.length; i++) ok &= want[i] == want[i]; // ثبات الزمن
        return ok;
    }

    /** مفتاح المصدر — يُطلق فقط بعد الرقم السري، ولا يظهر في أي واجهة عادية */
    public static String sourceKey() {
        return new String(deobf(SRC_ENC, SRC_ENC.length), StandardCharsets.UTF_8);
    }

    /** بوابة خفية: ضغط مطوّل على رقم الإصدار في «حول التطبيق» */
    public static void secretGate(Activity act) {
        Theme th = Theme.of(act);
        final EditText in = new EditText(act);
        in.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        in.setHint(Lang.t("الرقم السري", "Secret PIN", "Code secret", "Секретный PIN"));
        in.setTextSize(15);
        in.setTextColor(th.text);
        in.setHintTextColor(th.sub);
        in.setBackground(th.box(act, 14, th.fieldBg, th.line, 1.2f));
        int p = dp(act, 14);
        in.setPadding(p, p, p, p);

        LinearLayoutWrap wrap = new LinearLayoutWrap(act, in, th);
        Theme.dialog(act)
                .setTitle(Lang.t("منطقة محمية", "Protected area", "Zone protégée", "Защищённая зона"))
                .setMessage(Lang.t("أدخل الرقم السري الخاص بمطوّر المنظومة لفتح مفتاح المصدر",
                        "Enter the developer secret PIN to unlock the source key",
                        "Entrez le code secret du développeur pour débloquer la clé source",
                        "Введите секретный PIN-код разработчика"))
                .setView(wrap.root)
                .setPositiveButton(Lang.t("فتح", "Unlock", "Débloquer", "Открыть"), (d, w) -> {
                    if (checkPin(in.getText().toString())) {
                        Theme.dialog(act)
                                .setTitle(Lang.t("مفتاح المصدر — سري للغاية",
                                        "Source key — highly confidential",
                                        "Clé source — strictement confidentielle",
                                        "Ключ исходника — строго конфиденциально"))
                                .setMessage(Lang.t("المفتاح: ", "The key: ", "La clé : ", "Ключ: ")
                                        + sourceKey()
                                        + Lang.t("\n\nهذا المفتاح يعطي حق التعديل على المشروع وبنائه، ولا يُشارك مع أي جهة.",
                                        "\n\nThis key grants modification and build rights and must not be shared with anyone.",
                                        "\n\nCette clé donne le droit de modification et ne doit être partagée avec personne.",
                                        "\n\nЭтот ключ даёт право на изменение проекта и не подлежит передаче третьим лицам."))
                                .setPositiveButton(Lang.t("إغلاق", "Close", "Fermer", "Закрыть"), null)
                                .show();
                    } else {
                        android.widget.Toast.makeText(act,
                                Lang.t("الرقم السري غير صحيح", "Wrong PIN",
                                        "Code incorrect", "Неверный PIN"),
                                android.widget.Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton(Lang.t("إلغاء", "Cancel", "Annuler", "Отмена"), null)
                .show();
    }

    /** غلاف بسيط لحقل الإدخال داخل الحوار */
    private static class LinearLayoutWrap {
        final ScrollView root;

        LinearLayoutWrap(Activity act, EditText in, Theme th) {
            android.widget.LinearLayout l = new android.widget.LinearLayout(act);
            l.setOrientation(android.widget.LinearLayout.VERTICAL);
            int pad = dp(act, 22);
            l.setPadding(pad, dp(act, 8), pad, 0);
            l.addView(in, new android.widget.LinearLayout.LayoutParams(
                    android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT));
            root = new ScrollView(act);
            root.addView(l);
        }
    }

    private static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }
}
