package com.mmsa.records;

import android.content.Context;
import android.content.SharedPreferences;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Locale;

/** الحساب المحلي للمستخدم: تسجيل حساب جديد وتسجيل الدخول بالبريد الإلكتروني
 *  وكلمة السر (هاش SHA-256 مُملّح ومتكرر — لا تُخزن كلمة السر نفسها أبداً)،
 *  أو ربط فوري بحساب Gmail مختار من الجهاز. كل شيء داخل ذاكرة الهاتف فقط
 *  ولا يُرسل أي بيانات إلى أي جهة. */
public class Auth {

    public static final int REQ_GOOGLE = 4711;

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences("mmsa_auth", Context.MODE_PRIVATE);
    }

    /** هل توجد جلسة دخول نشطة؟ */
    public static boolean isAuthed(Context c) {
        return !prefs(c).getString("session", "").isEmpty();
    }

    /** تسجيل حساب جديد بالبريد وكلمة السر — يعيد رسالة خطأ أو null عند النجاح */
    public static String signup(Context c, String email, String pwd) {
        String mail = norm(email);
        if (!mail.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$"))
            return Lang.t("صيغة البريد الإلكتروني غير صحيحة",
                    "Invalid email address", "Adresse e-mail invalide", "Неверный адрес эл. почты");
        if (pwd.length() < 6)
            return Lang.t("كلمة السر يجب أن تكون 6 أحرف على الأقل",
                    "Password must be at least 6 characters",
                    "Le mot de passe doit contenir au moins 6 caractères",
                    "Пароль должен содержать не менее 6 символов");
        SharedPreferences p = prefs(c);
        if (!p.getString("email", "").isEmpty())
            return Lang.t("يوجد حساب مُسجّل مسبقاً على هذا الهاتف — سجّل الدخول أو أعد تعيين الحساب",
                    "An account already exists on this phone — sign in or reset it",
                    "Un compte existe déjà — connectez-vous ou réinitialisez-le",
                    "Аккаунт уже существует — войдите или сбросьте его");
        String salt = randSalt();
        p.edit().putString("email", mail)
                .putString("salt", salt)
                .putString("hash", hash(pwd, salt))
                .putString("provider", "email")
                .putString("session", mail)
                .apply();
        return null;
    }

    /** تسجيل الدخول بالبريد وكلمة السر — يعيد رسالة خطأ أو null عند النجاح */
    public static String login(Context c, String email, String pwd) {
        SharedPreferences p = prefs(c);
        String stored = p.getString("email", "");
        if (stored.isEmpty())
            return Lang.t("لا يوجد حساب على هذا الهاتف — أنشئ حساباً جديداً",
                    "No account on this phone — create a new one",
                    "Aucun compte sur ce téléphone — créez-en un",
                    "На этом телефоне нет аккаунта — создайте новый");
        if (!norm(email).equals(stored))
            return Lang.t("البريد الإلكتروني غير مطابق للحساب المسجل",
                    "Email does not match the registered account",
                    "L'e-mail ne correspond pas au compte enregistré",
                    "Эл. почта не совпадает с зарегистрированным аккаунтом");
        String hash = p.getString("hash", "");
        if (hash.isEmpty())
            return Lang.t("الحساب مُربط بحساب Google — استخدم زر المتابعة بحساب Google",
                    "Account is linked to Google — use Continue with Google",
                    "Compte lié à Google — continuez avec Google",
                    "Аккаунт привязан к Google — войдите через Google");
        if (!hash(pwd, p.getString("salt", "")).equals(hash))
            return Lang.t("كلمة السر غير صحيحة",
                    "Incorrect password", "Mot de passe incorrect", "Неверный пароль");
        p.edit().putString("session", stored).apply();
        return null;
    }

    /** ربط فوري بحساب Gmail المختار من الجهاز: دخول مباشر بلا كلمة سر */
    public static void googleLogin(Context c, String email) {
        String mail = norm(email);
        if (mail.isEmpty()) return;
        SharedPreferences p = prefs(c);
        SharedPreferences.Editor e = p.edit();
        boolean fresh = !mail.equals(p.getString("email", ""));
        if (fresh) e.remove("salt").remove("hash"); // حساب جديد بالربط
        e.putString("email", mail)
                .putString("provider", "google")
                .putString("session", mail)
                .apply();
    }

    /** إعادة تعيين الحساب المحلي (لمن نسى كلمة السر): يمسح الحساب ويطلب إنشاء حساب جديد */
    public static void resetAccount(Context c) {
        prefs(c).edit().clear().apply();
    }

    /** تسجيل الخروج: الجلسة فقط — بيانات الموظفين تبقى محفوظة */
    public static void logout(Context c) {
        prefs(c).edit().remove("session").apply();
    }

    private static String norm(String email) {
        return email == null ? "" : email.trim().toLowerCase(Locale.US);
    }

    /** هاش مُملّح ومتكرر: SHA-256 بـ 20000 دورة — تخزين أحادي الاتجاه */
    private static String hash(String pwd, String salt) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] b = (salt + ":" + pwd).getBytes(StandardCharsets.UTF_8);
            for (int i = 0; i < 20000; i++) {
                md.update((byte) i);
                b = md.digest(b);
            }
            StringBuilder s = new StringBuilder();
            for (byte x : b) s.append(String.format(Locale.US, "%02x", x));
            return s.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private static String randSalt() {
        SecureRandom r = new SecureRandom();
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < 16; i++) s.append("0123456789abcdef".charAt(r.nextInt(16)));
        return s.toString();
    }
}
