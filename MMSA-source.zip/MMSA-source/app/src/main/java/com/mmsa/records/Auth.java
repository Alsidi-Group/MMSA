package com.mmsa.records;

import android.content.Context;
import android.content.SharedPreferences;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Locale;

/** الحسابات المحلية للمستخدمين: تسجيل حساب جديد وتسجيل الدخول بالبريد
 *  الإلكتروني (Gmail) وكلمة السر (هاش SHA-256 مُملّح ومتكرر — لا تُخزن كلمة
 *  السر نفسها أبداً)، أو ربط فوري بحساب Gmail مختار من الجهاز. كل الحسابات
 *  وسجل الدخول تُحفظ في ملف «mmsa_users.json» داخل ملفات التطبيق عبر
 *  AuthStore — بدون تكرار لنفس البريد — ولا يُرسل أي بيانات إلى أي جهة. */
public class Auth {

    public static final int REQ_GOOGLE = 4711;

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences("mmsa_auth", Context.MODE_PRIVATE);
    }

    /** مخزن المستخدمين وسجل الدخول: ملف mmsa_users.json داخل ملفات التطبيق */
    public static AuthStore store(Context c) {
        return new AuthStore(c.getApplicationContext().getFilesDir());
    }

    /** ترحيل الحساب القديم (قبل 1.4.5) من SharedPreferences إلى ملف المستخدمين */
    private static void migrate(Context c, AuthStore st) {
        if (st.userCount() > 0) return;
        SharedPreferences p = prefs(c);
        String email = p.getString("email", "");
        if (email.isEmpty()) return;
        AuthStore.User u = new AuthStore.User();
        u.email = email;
        u.salt = p.getString("salt", "");
        u.hash = p.getString("hash", "");
        u.provider = p.getString("provider", "email");
        if (st.add(u) == null) // نجاح الترحيل → تنظيف المفاتيح القديمة (تبقى الجلسة)
            p.edit().remove("email").remove("salt").remove("hash").remove("provider").apply();
    }

    /** هل توجد جلسة دخول نشطة؟ */
    public static boolean isAuthed(Context c) {
        return !prefs(c).getString("session", "").isEmpty();
    }

    /** تسجيل حساب جديد بالبريد وكلمة السر — يعيد رسالة خطأ أو null عند النجاح */
    public static String signup(Context c, String email, String pwd) {
        String mail = norm(email);
        if (!mail.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$"))
            return Lang.t("صيغة البريد الإلكتروني غير صحيحة",
                    "Invalid email address", "Adresse e-mail invalide", "Неверный адрес эл. почты");
        if (pwd.length() < 6)
            return Lang.t("كلمة السر يجب أن تكون 6 أحرف على الأقل",
                    "Password must be at least 6 characters",
                    "Le mot de passe doit contenir au moins 6 caractères",
                    "Пароль должен содержать не менее 6 символов");
        AuthStore st = store(c);
        migrate(c, st);
        AuthStore.User u = new AuthStore.User();
        u.email = mail;
        u.salt = randSalt();
        u.hash = hash(pwd, u.salt);
        u.provider = "email";
        String err = st.add(u); // يمنع تكرار تسجيل نفس البريد
        if (err != null) return err;
        st.log(mail, AuthStore.ACT_SIGNUP, "email");
        prefs(c).edit().putString("session", mail).apply();
        return null;
    }

    /** تسجيل الدخول بالبريد وكلمة السر — يعيد رسالة خطأ أو null عند النجاح */
    public static String login(Context c, String email, String pwd) {
        String mail = norm(email);
        AuthStore st = store(c);
        migrate(c, st);
        AuthStore.User u = st.find(mail);
        if (u == null)
            return Lang.t("لا يوجد حساب بهذا البريد — أنشئ حساباً جديداً",
                    "No account with this email — create a new one",
                    "Aucun compte avec cet e-mail — créez-en un",
                    "Нет аккаунта с этой эл. почтой — создайте новый");
        if (u.hash.isEmpty())
            return Lang.t("الحساب مُربط بحساب Google — استخدم زر المتابعة بحساب Google",
                    "Account is linked to Google — use Continue with Google",
                    "Compte lié à Google — continuez avec Google",
                    "Аккаунт привязан к Google — войдите через Google");
        if (!hash(pwd, u.salt).equals(u.hash)) {
            st.log(mail, AuthStore.ACT_LOGIN_FAILED, "email"); // تسجيل المحاولة الفاشلة
            return Lang.t("كلمة السر غير صحيحة",
                    "Incorrect password", "Mot de passe incorrect", "Неверный пароль");
        }
        st.touch(mail);
        st.log(mail, AuthStore.ACT_LOGIN, u.provider);
        prefs(c).edit().putString("session", mail).apply();
        return null;
    }

    /** ربط فوري بحساب Gmail المختار من الجهاز: دخول مباشر بلا كلمة سر */
    public static void googleLogin(Context c, String email) {
        String mail = norm(email);
        if (mail.isEmpty()) return;
        AuthStore st = store(c);
        migrate(c, st);
        if (st.find(mail) == null) {
            AuthStore.User u = new AuthStore.User();
            u.email = mail;
            u.provider = "google"; // ربط بلا كلمة سر
            if (st.add(u) != null) return;
        } else {
            st.setProvider(mail, "google"); // يحافظ على هاش كلمة السر إن وُجد
        }
        st.touch(mail);
        st.log(mail, AuthStore.ACT_GOOGLE, "google");
        prefs(c).edit().putString("session", mail).apply();
    }

    /** إعادة تعيين حساب بالبريد (لمن نسى كلمة السر): يحذف حسابه من ملف
     *  المستخدمين ليتمكن من إنشاء حساب جديد بالبريد نفسه — يعيد رسالة خطأ أو null */
    public static String resetAccount(Context c, String email) {
        AuthStore st = store(c);
        String mail = norm(email);
        if (!st.remove(mail))
            return Lang.t("لا يوجد حساب بهذا البريد",
                    "No account with this email", "Aucun compte avec cet e-mail",
                    "Нет аккаунта с этой эл. почтой");
        st.log(mail, AuthStore.ACT_RESET, "email");
        return null;
    }

    /** تسجيل الخروج: الجلسة فقط — الحسابات وبيانات الموظفين تبقى محفوظة */
    public static void logout(Context c) {
        String s = prefs(c).getString("session", "");
        if (!s.isEmpty()) store(c).log(s, AuthStore.ACT_LOGOUT, "");
        prefs(c).edit().remove("session").apply();
    }

    private static String norm(String email) {
        return email == null ? "" : email.trim().toLowerCase(Locale.US);
    }

    /** هاش مُملّح ومتكرر: SHA-256 بـ 20000 دورة — تخزين أحادي الاتجاه */
    public static String hash(String pwd, String salt) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] b = (salt + ":" + pwd).getBytes(StandardCharsets.UTF_8);
            for (int i = 0; i < 20000; i++) {
                md.update((byte) i);
                b = md.digest(b);
            }
            StringBuilder s = new StringBuilder();
            for (byte x : b) s.append(String.format(Locale.US, "%02x", x));
            return s.toString();
        } catch (Exception e) {
            return "";
        }
    }

    static String randSalt() {
        SecureRandom r = new SecureRandom();
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < 16; i++) s.append("0123456789abcdef".charAt(r.nextInt(16)));
        return s.toString();
    }
}
