package com.mmsa.records;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/** أساس كل الشاشات: فرض اللغة العربية + RTL + الألوان + هيكل الصفحة */
public abstract class BaseActivity extends Activity {

    protected Theme th;

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(Theme.arabic(base));
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        th = Theme.of(this);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        applyBars();
    }

    @Override
    protected void onResume() {
        super.onResume();
        th = Theme.of(this); // تحديث الألوان بعد تبديل الثيم
        applyBars();
    }

    private void applyBars() {
        getWindow().setStatusBarColor(th.primaryDark);
        getWindow().setNavigationBarColor(th.primaryDark);
    }

    /** هيكل الصفحة: شريط علوي (شعار + عنوان) + جسم + شريط سفلي اختياري */
    public LinearLayout page(String title, View body, View bottomBar) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(th.bg);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setBackgroundColor(th.primary);
        header.setPadding(dp(16), dp(10), dp(16), dp(10));
        header.setElevation(dp(4));

        ImageView iv = new ImageView(this);
        Bitmap lg = Theme.loadLogo(this);
        iv.setImageBitmap(lg);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(34), dp(34));
        ip.rightMargin = dp(12);
        header.addView(iv, ip);

        TextView t = th.text(this, title, 18, th.onPrimary, true);
        header.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        root.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(56)));
        root.addView(body, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        if (bottomBar != null) {
            root.addView(bottomBar, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        setContentView(root);
        return root;
    }

    protected int dp(float v) {
        return Theme.dp(this, v);
    }

    protected LinearLayout.LayoutParams match() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    protected LinearLayout.LayoutParams matchM(int bottomDp) {
        LinearLayout.LayoutParams l = match();
        l.bottomMargin = dp(bottomDp);
        return l;
    }

    protected LinearLayout.LayoutParams half() {
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        l.setMargins(dp(4), 0, dp(4), 0);
        return l;
    }

    protected void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    protected void confirm(String title, String msg, final Runnable onYes) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(msg)
                .setPositiveButton("تأكيد", (d, w) -> onYes.run())
                .setNegativeButton("إلغاء", null)
                .show();
    }

    public static Context arabic(Context c) {
        Locale ar = new Locale("ar");
        Configuration cfg = new Configuration(c.getResources().getConfiguration());
        cfg.setLocale(ar);
        return c.createConfigurationContext(cfg);
    }
}
