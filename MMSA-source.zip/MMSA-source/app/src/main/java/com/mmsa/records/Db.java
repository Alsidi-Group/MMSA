package com.mmsa.records;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.LinkedHashMap;

/** قاعدة البيانات المحلية SQLite داخل ذاكرة الهاتف + منع التكرار بالمفاتيح */
public class Db extends SQLiteOpenHelper {

    public static final String DB_NAME = "mmsa.db";
    private static Db inst;

    public static synchronized Db get(Context c) {
        if (inst == null) inst = new Db(c.getApplicationContext());
        return inst;
    }

    /** إغلاق القاعدة قبل الاستعادة */
    public static synchronized void reset() {
        if (inst != null) {
            try { inst.close(); } catch (Exception ignored) {}
            inst = null;
        }
    }

    private Db(Context c) {
        super(c, DB_NAME, null, 1);
        ctx = c.getApplicationContext();
    }

    private final Context ctx;

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE employees ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "empType TEXT, finNumber TEXT, milNumber TEXT, rank TEXT, nationalId TEXT, "
                + "fullName TEXT, unit TEXT, joinDate TEXT, appointDate TEXT, appointDecree TEXT, "
                + "lastPromotion TEXT, dueDate TEXT, grade TEXT, bankName TEXT, bankBranch TEXT, "
                + "bankAccount TEXT, salary TEXT, createdAt INTEGER, updatedAt INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) { /* الإصدار الأول */ }

    public String dbPath() {
        return ctx.getDatabasePath(DB_NAME).getAbsolutePath();
    }

    /** دمج محتوى WAL في الملف الرئيسي قبل النسخ الاحتياطي */
    public void checkpoint() {
        try {
            getWritableDatabase().execSQL("PRAGMA wal_checkpoint(FULL)");
        } catch (Exception ignored) {}
    }

    private ContentValues cv(Employee e) {
        ContentValues v = new ContentValues();
        for (String col : Employee.COLS) v.put(col, e.val(col));
        return v;
    }

    private static boolean empty(Employee e, String k) {
        return e.val(k).trim().isEmpty();
    }

    /** التحقق من الإلزامية ومنع التكرار عبر (الرقم الوطني / المالي / العسكري). يُعيد رسالة خطأ أو null */
    public String validate(Employee e) {
        if (empty(e, "fullName")) return "الاسم الرباعي إلزامي";
        if (empty(e, "rank")) return "الرتبة إلزامية";
        if (empty(e, "finNumber") && empty(e, "milNumber") && empty(e, "nationalId"))
            return "أدخل أحد مفاتيح عدم التكرار: الرقم الوطني أو رقم الوظيفي (المالي) أو الرقم العسكري";
        return findDup(e);
    }

    /** البحث عن تكرار في المفاتيح الثلاثة مع استثناء السجل الحالي */
    public String findDup(Employee e) {
        String[] keys = {"nationalId", "finNumber", "milNumber"};
        SQLiteDatabase db = getReadableDatabase();
        for (String col : keys) {
            String v = e.val(col).trim();
            if (v.isEmpty()) continue;
            Cursor c = db.query("employees", new String[]{"fullName"},
                    col + "=? AND id<>?", new String[]{v, String.valueOf(e.id)},
                    null, null, null);
            String err = null;
            if (c.moveToFirst()) {
                err = Employee.labelOf(col) + " («" + v + "») مسجّل مسبقاً للموظف: " + c.getString(0);
            }
            c.close();
            if (err != null) return err;
        }
        return null;
    }

    public boolean insert(Employee e) {
        if (findDup(e) != null) return false;
        long now = System.currentTimeMillis();
        e.createdAt = now;
        e.updatedAt = now;
        ContentValues v = cv(e);
        v.put("createdAt", now);
        v.put("updatedAt", now);
        return getWritableDatabase().insert("employees", null, v) > 0;
    }

    public boolean update(Employee e) {
        if (findDup(e) != null) return false;
        e.updatedAt = System.currentTimeMillis();
        ContentValues v = cv(e);
        v.put("updatedAt", e.updatedAt);
        return getWritableDatabase().update("employees", v, "id=?",
                new String[]{String.valueOf(e.id)}) > 0;
    }

    public int delete(int id) {
        return getWritableDatabase().delete("employees", "id=?",
                new String[]{String.valueOf(id)});
    }

    private static final String SEL =
            "SELECT id," + joinCols() + ",createdAt,updatedAt FROM employees";

    private static String joinCols() {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < Employee.COLS.length; i++) {
            if (i > 0) b.append(",");
            b.append(Employee.COLS[i]);
        }
        return b.toString();
    }

    private Employee fromCursor(Cursor c) {
        Employee e = new Employee();
        e.id = c.getInt(0);
        for (int i = 0; i < Employee.COLS.length; i++) {
            String v = c.getString(i + 1);
            e.d.put(Employee.COLS[i], v == null ? "" : v);
        }
        e.createdAt = c.getLong(Employee.COLS.length + 1);
        e.updatedAt = c.getLong(Employee.COLS.length + 2);
        return e;
    }

    public Employee get(int id) {
        Cursor c = getReadableDatabase().rawQuery(SEL + " WHERE id=?",
                new String[]{String.valueOf(id)});
        Employee e = null;
        if (c.moveToFirst()) e = fromCursor(c);
        c.close();
        return e;
    }

    public ArrayList<Employee> all() {
        Cursor c = getReadableDatabase().rawQuery(SEL + " ORDER BY fullName", null);
        ArrayList<Employee> out = new ArrayList<>();
        while (c.moveToNext()) out.add(fromCursor(c));
        c.close();
        return out;
    }

    public ArrayList<Employee> searchName(String q) {
        Cursor c = getReadableDatabase().rawQuery(SEL + " WHERE fullName LIKE ? ORDER BY fullName",
                new String[]{"%" + q + "%"});
        ArrayList<Employee> out = new ArrayList<>();
        while (c.moveToNext()) out.add(fromCursor(c));
        c.close();
        return out;
    }

    /** أعمدة البحث المسموح بها فقط (حماية من حقن اسم العمود) */
    private static final java.util.Set<String> SEARCHABLE = new java.util.HashSet<>(
            java.util.Arrays.asList("nationalId", "finNumber", "milNumber"));

    /** مطابقة تامة على عمود محدد (nationalId / finNumber / milNumber فقط) */
    public ArrayList<Employee> searchByCol(String col, String v) {
        ArrayList<Employee> out = new ArrayList<>();
        if (!SEARCHABLE.contains(col)) return out; // رفض أي عمود غير مسموح
        Cursor c = getReadableDatabase().rawQuery(SEL + " WHERE " + col + "=? ORDER BY fullName",
                new String[]{v});
        while (c.moveToNext()) out.add(fromCursor(c));
        c.close();
        return out;
    }

    /** بحث عام في الاسم/الأرقام/الرتبة (للتصفية في عرض الكل) */
    public ArrayList<Employee> searchAll(String q) {
        String like = "%" + q + "%";
        Cursor c = getReadableDatabase().rawQuery(SEL
                        + " WHERE fullName LIKE ? OR nationalId LIKE ? OR finNumber LIKE ? OR milNumber LIKE ? OR rank LIKE ?"
                        + " ORDER BY fullName",
                new String[]{like, like, like, like, like});
        ArrayList<Employee> out = new ArrayList<>();
        while (c.moveToNext()) out.add(fromCursor(c));
        c.close();
        return out;
    }

    public int count() {
        Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM employees", null);
        int n = 0;
        if (c.moveToFirst()) n = c.getInt(0);
        c.close();
        return n;
    }

    public int countType(String t) {
        Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM employees WHERE empType=?",
                new String[]{t});
        int n = 0;
        if (c.moveToFirst()) n = c.getInt(0);
        c.close();
        return n;
    }

    public LinkedHashMap<String, Integer> rankCounts() {
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT rank, COUNT(*) FROM employees GROUP BY rank ORDER BY COUNT(*) DESC", null);
        LinkedHashMap<String, Integer> out = new LinkedHashMap<>();
        while (c.moveToNext()) {
            String r = c.getString(0);
            if (r == null || r.trim().isEmpty()) r = "بدون رتبة";
            out.put(r, c.getInt(1));
        }
        c.close();
        return out;
    }

    public Employee lastAdded() {
        Cursor c = getReadableDatabase().rawQuery(SEL + " ORDER BY id DESC LIMIT 1", null);
        Employee e = null;
        if (c.moveToFirst()) e = fromCursor(c);
        c.close();
        return e;
    }

    /** استيراد دفعة سجلات مع تجاهل المكرر. يُعيد [مضاف، مكرر، غير صالح] */
    public int[] importRows(ArrayList<Employee> list) {
        int added = 0, dup = 0, bad = 0;
        for (Employee e : list) {
            if (empty(e, "fullName")) { bad++; continue; }
            if (empty(e, "finNumber") && empty(e, "milNumber") && empty(e, "nationalId")) { bad++; continue; }
            if (findDup(e) != null) { dup++; continue; }
            if (insert(e)) added++; else dup++;
        }
        return new int[]{added, dup, bad};
    }
}
